<?php
/**
 * نمونه‌ی اتصال فرم اختصاصی به WP Math Captcha.
 *
 * این فایل خودکار اجرا نمی‌شود. آن را در functions.php قالب فرزند یا
 * افزونه‌ی اختصاصی خود کپی کنید و نام توابع/handler را با افزونه‌ی خودتان
 * هماهنگ نمایید.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * خروجی کپچا برای فرم اختصاصی.
 *
 * این خروجی را داخل <form>، ترجیحاً قبل از دکمه‌ی submit قرار دهید.
 *
 * @return string
 */
function wpmc_example_custom_form_captcha() {
	if ( ! class_exists( 'WP_MC_Captcha' ) ) {
		return '';
	}

	return WP_MC_Captcha::output();
}

/**
 * اعتبارسنجی داده‌های فرم اختصاصی.
 *
 * @param array  $source  معمولاً $_POST یا آرایه‌ی فیلدهای فرم.
 * @param string $context نام فرم برای لاگ.
 * @return true|WP_Error
 */
function wpmc_example_verify_custom_form( $source, $context = 'custom-plugin-form' ) {
	$source = is_array( $source ) ? wp_unslash( $source ) : [];

	return WP_MC_Captcha::verify(
		isset( $source['wpmc_answer'] ) ? $source['wpmc_answer'] : '',
		isset( $source['wpmc_token'] ) ? $source['wpmc_token'] : '',
		isset( $source['wpmc_website'] ) ? $source['wpmc_website'] : '',
		$context
	);
}

/*
 * نمونه‌ی استفاده در handler افزونه‌ی مقصد:
 *
 * $captcha = wpmc_example_verify_custom_form( $_POST, 'my-plugin-contact' );
 * if ( is_wp_error( $captcha ) ) {
 *     // فرم معمولی:
 *     wp_die( esc_html( $captcha->get_error_message() ), '', [ 'response' => 400 ] );
 *
 *     // فرم AJAX:
 *     // wp_send_json_error( [ 'message' => $captcha->get_error_message() ], 400 );
 * }
 *
 * // فقط بعد از این قسمت ایمیل، ذخیره یا ساخت سفارش را انجام دهید.
 */

/*
 * اگر افزونه‌ی مقصد نام فیلدهای متفاوت می‌خواهد، خروجی را این‌گونه بسازید:
 *
 * echo WP_MC_Captcha::output([
 *     'answer_name' => 'captcha_answer',
 *     'token_name'  => 'captcha_token',
 *     'hp_name'     => 'captcha_hp',
 * ]);
 *
 * و سپس همان نام‌ها را به verify بدهید:
 *
 * $captcha = WP_MC_Captcha::verify(
 *     $_POST['captcha_answer'] ?? '',
 *     $_POST['captcha_token'] ?? '',
 *     $_POST['captcha_hp'] ?? '',
 *     'my-plugin-custom-form'
 * );
 */

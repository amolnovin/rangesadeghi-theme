<?php
/**
 * هسته‌ی افزونه: تنظیمات، شناسایی IP، ثبت رویدادها و صفحه‌های مدیریت.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_MC_Core {

	/**
	 * نام option اصلی.
	 */
	const OPT = 'wpmc_settings';

	/**
	 * تنظیمات پیش‌فرض.
	 *
	 * @var array
	 */
	const DEFAULTS = [
		'enabled'            => 1,
		'difficulty'         => 'medium',
		'ops'                => [ '+', '-' ],
		'max_num'            => 20,
		'persian_digits'     => 1,
		'min_time'           => 3,
		'max_attempts'       => 3,
		'fail_threshold'     => 8,
		'lock_minutes'       => 30,
		'gen_limit'          => 300,
		'elementor_scope'    => 'all',
		'elementor_form_ids' => '',
		'apply_comments'     => 1,
		'apply_login'        => 1,
		'apply_cf7'          => 1,
		'block_bot_ua'       => 1,
		'trust_proxy'        => 0,
		'log_events'         => 1,
		'debug'              => 0,
	];

	/**
	 * تنظیمات فعلی (پیش‌فرض + ذخیره‌شده).
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPT, [] );
		if ( ! is_array( $saved ) ) {
			$saved = [];
		}
		return array_merge( self::DEFAULTS, $saved );
	}

	/**
	 * خواندن یک تنظیم.
	 *
	 * @param string $key     کلید.
	 * @param mixed  $default مقدار جایگزین.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * IP واقعی‌ترین ممکن کلاینت.
	 *
	 * X-Forwarded-For فقط وقتی معتبر است که «اعتماد به سرور واسط» روشن باشد
	 * (وگرنه ربات می‌تواند آن را جعل کند).
	 *
	 * @return string
	 */
	public static function ip() {
		$ip = '';
		if ( self::get( 'trust_proxy' ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$parts     = explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			$candidate = trim( $parts[0] );
			if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
				$ip = $candidate;
			}
		}
		if ( '' === $ip ) {
			$ip = isset( $_SERVER['REMOTE_ADDR'] )
				? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
				: '0.0.0.0';
		}
		return $ip;
	}

	/**
	 * کلید امضای توکن‌ها (وابسته به salt اختصاصی سایت).
	 *
	 * @return string
	 */
	public static function key() {
		return wp_salt( 'auth' ) . '::wpmc::' . ( defined( 'WPMC_VERSION' ) ? WPMC_VERSION : '1.0' );
	}

	/**
	 * ثبت یک رویداد امنیتی (آخرین ۲۰۰ رویداد).
	 *
	 * @param string $reason  کد دلیل.
	 * @param string $context منبع.
	 */
	public static function log_event( $reason, $context = '' ) {
		if ( ! self::get( 'log_events' ) ) {
			return;
		}
		$events        = get_transient( 'wpmc_events' );
		$events        = is_array( $events ) ? $events : [];
		$events[]      = [
			't'      => time(),
			'ip'     => self::ip(),
			'reason' => $reason,
			'ctx'    => (string) $context,
		];
		$events        = array_slice( $events, -200 );
		set_transient( 'wpmc_events', $events, 30 * DAY_IN_SECONDS );
	}

	/**
	 * رویدادهای ثبت‌شده.
	 *
	 * @return array
	 */
	public static function events() {
		$events = get_transient( 'wpmc_events' );
		return is_array( $events ) ? $events : [];
	}

	/**
	 * پاک‌سازی رویدادها.
	 */
	public static function clear_log() {
		delete_transient( 'wpmc_events' );
	}

	/* ------------------------------------------------------------------
	 * مدیریت
	 * ------------------------------------------------------------------ */

	/**
	 * ثبت هوک‌های مدیریت.
	 */
	public static function init_admin() {
		add_action( 'admin_menu', [ __CLASS__, 'admin_menu' ] );
		add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
		add_action( 'admin_post_wpmc_clear_log', [ __CLASS__, 'handle_clear_log' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'admin_assets' ] );
	}

	/**
	 * منوی مدیریت.
	 */
	public static function admin_menu() {
		add_menu_page(
			'کپچای ریاضی',
			'کپچای ریاضی',
			'manage_options',
			'wp-math-captcha',
			[ __CLASS__, 'render_settings' ],
			'dashicons-lock',
			100
		);
		add_submenu_page( 'wp-math-captcha', 'تنظیمات کپچا', 'تنظیمات', 'manage_options', 'wp-math-captcha', [ __CLASS__, 'render_settings' ] );
		add_submenu_page( 'wp-math-captcha', 'رویدادهای امنیتی', 'رویدادها', 'manage_options', 'wp-math-captcha-logs', [ __CLASS__, 'render_logs' ] );
	}

	/**
	 * ثبت تنظیمات (با sanitize).
	 *
	 * فقط از فرم کلاسیک سه‌پارامتری register_setting استفاده می‌شود؛
	 * فرم «آرایه‌ی تک‌پارامتری» در هیچ نسخه‌ای از هسته‌ی وردپرس وجود ندارد.
	 */
	public static function register_settings() {
		register_setting(
			'wpmc_group',
			self::OPT,
			[ 'sanitize_callback' => [ __CLASS__, 'sanitize' ] ]
		);
	}

	/**
	 * پاک‌سازی و محدودسازی ورودی‌ها.
	 *
	 * @param array $in ورودی فرم.
	 * @return array
	 */
	public static function sanitize( $in ) {
		$in  = is_array( $in ) ? $in : [];
		$out = self::all();

		$out['enabled'] = empty( $in['enabled'] ) ? 0 : 1;

		$d = isset( $in['difficulty'] ) ? (string) $in['difficulty'] : 'medium';
		$out['difficulty'] = in_array( $d, [ 'easy', 'medium', 'hard', 'custom' ], true ) ? $d : 'medium';

		if ( 'custom' === $out['difficulty'] ) {
			$ops = [];
			if ( ! empty( $in['ops'] ) && is_array( $in['ops'] ) ) {
				if ( ! empty( $in['ops']['plus'] ) ) {
					$ops[] = '+';
				}
				if ( ! empty( $in['ops']['minus'] ) ) {
					$ops[] = '-';
				}
				if ( ! empty( $in['ops']['mul'] ) ) {
					$ops[] = 'x';
				}
			}
			$out['ops'] = $ops ? $ops : [ '+' ];
			$out['max_num'] = max( 2, min( 99, absint( isset( $in['max_num'] ) ? $in['max_num'] : 20 ) ) );
		}

		$out['persian_digits'] = empty( $in['persian_digits'] ) ? 0 : 1;
		$out['min_time']       = max( 0, min( 60, absint( isset( $in['min_time'] ) ? $in['min_time'] : 3 ) ) );
		$out['max_attempts']   = max( 1, min( 10, absint( isset( $in['max_attempts'] ) ? $in['max_attempts'] : 3 ) ) );
		$out['fail_threshold'] = max( 1, min( 100, absint( isset( $in['fail_threshold'] ) ? $in['fail_threshold'] : 8 ) ) );
		$out['lock_minutes']   = max( 1, min( 1440, absint( isset( $in['lock_minutes'] ) ? $in['lock_minutes'] : 30 ) ) );
		$out['gen_limit']      = max( 1, min( 1000, absint( isset( $in['gen_limit'] ) ? $in['gen_limit'] : 300 ) ) );

		$scope = isset( $in['elementor_scope'] ) ? (string) $in['elementor_scope'] : 'all';
		$out['elementor_scope'] = in_array( $scope, [ 'all', 'selected', 'off' ], true ) ? $scope : 'all';
		$out['elementor_form_ids'] = sanitize_text_field( isset( $in['elementor_form_ids'] ) ? $in['elementor_form_ids'] : '' );

		$out['apply_comments'] = empty( $in['apply_comments'] ) ? 0 : 1;
		$out['apply_login']    = empty( $in['apply_login'] ) ? 0 : 1;
		$out['apply_cf7']      = empty( $in['apply_cf7'] ) ? 0 : 1;
		$out['block_bot_ua']   = empty( $in['block_bot_ua'] ) ? 0 : 1;
		$out['trust_proxy']    = empty( $in['trust_proxy'] ) ? 0 : 1;
		$out['log_events']     = empty( $in['log_events'] ) ? 0 : 1;
		$out['debug']          = empty( $in['debug'] ) ? 0 : 1;

		return $out;
	}

	/**
	 * پاک‌سازی رویدادها (با nonce).
	 */
	public static function handle_clear_log() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی ندارید.', 'wp-math-captcha' ) );
		}
		check_admin_referer( 'wpmc_clear_log' );
		self::clear_log();
		wp_safe_redirect( add_query_arg( [ 'page' => 'wp-math-captcha-logs', 'cleared' => 1 ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * داروهای پیش‌نمایش در صفحه‌ی مدیریت.
	 *
	 * @param string $hook hook.
	 */
	public static function admin_assets( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'wp-math-captcha' ) ) {
			return;
		}
		wp_enqueue_style( 'wpmc', WPMC_URL . 'assets/wpmc.css', [], WPMC_VERSION );
		wp_enqueue_script( 'wpmc', WPMC_URL . 'assets/wpmc.js', [], WPMC_VERSION, true );
		wp_localize_script(
			'wpmc',
			'WPMC',
			[
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wpmc_frontend' ),
				'scope'   => 'off', // تزریق خودکار در مدیریت انجام نشود.
				'formIds' => [],
				'i18n'    => [
					'load' => __( 'در حال بارگذاری…', 'wp-math-captcha' ),
					'err'  => __( 'کپچا بارگذاری نشد. لطفاً صفحه را نوساری کنید.', 'wp-math-captcha' ),
					'rate' => __( 'تلاش‌های شما زیاد است؛ چند لحظه صبر کنید.', 'wp-math-captcha' ),
				],
			]
		);
	}

	/**
	 * یک ردیف جدول تنظیمات.
	 *
	 * @param string $label عنوان.
	 * @param string $input_html html ورودی.
	 * @param string $desc توضیح.
	 * @return string
	 */
	private static function row( $label, $input_html, $desc = '' ) {
		$desc_html = '' !== $desc ? '<p class="description">' . $desc . '</p>' : '';
		return '<tr><th scope="row">' . $label . '</th><td>' . $input_html . $desc_html . '</td></tr>';
	}

	/**
	 * صفحه‌ی تنظیمات.
	 */
	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s       = self::all();
		$el_pro  = defined( 'ELEMENTOR_PRO_VERSION' ) || class_exists( '\ElementorPro\Plugin' );
		$cf7     = defined( 'WPCF7_VERSION' );
		$ops_arr = (array) $s['ops'];

		$rows  = self::row(
			'فعال‌سازی',
			'<label><input type="checkbox" name="wpmc_settings[enabled]" value="1" ' . checked( 1, (int) $s['enabled'], false ) . '> کپچای ریاضی فعال است</label>',
			'با غیرفعال‌کردن، هیچ فرمی محافظت نمی‌شود.'
		);

		$rows .= self::row(
			'سطح دشواری مسئله',
			'<select name="wpmc_settings[difficulty]">'
			. '<option value="easy" ' . selected( $s['difficulty'], 'easy', false ) . '>آسان (جمع/تفریق، اعداد ۱ تا ۹)</option>'
			. '<option value="medium" ' . selected( $s['difficulty'], 'medium', false ) . '>متوسط (جمع/تفریق، اعداد ۱ تا ۲۰)</option>'
			. '<option value="hard" ' . selected( $s['difficulty'], 'hard', false ) . '>سخت (جمع/تفریق/ضرب، اعداد تا ۱۲)</option>'
			. '<option value="custom" ' . selected( $s['difficulty'], 'custom', false ) . '>سفارشی</option>'
			. '</select>',
			'در حالت «سفارشی»، عملیات و حد عدد در دو ردیف بعدی تعیین می‌شود.'
		);

		$ops_html = '<label style="display:inline-block;margin-left:14px"><input type="checkbox" name="wpmc_settings[ops][plus]" value="1" ' . checked( in_array( '+', $ops_arr, true ), true, false ) . '> جمع (+)</label>'
			. '<label style="display:inline-block;margin-left:14px"><input type="checkbox" name="wpmc_settings[ops][minus]" value="1" ' . checked( in_array( '-', $ops_arr, true ), true, false ) . '> تفریق (−)</label>'
			. '<label style="display:inline-block;margin-left:14px"><input type="checkbox" name="wpmc_settings[ops][mul]" value="1" ' . checked( in_array( 'x', $ops_arr, true ), true, false ) . '> ضرب (×)</label>';
		$rows .= self::row( 'عملیات (حالت سفارشی)', $ops_html, 'فقط وقتی که سطح دشواری «سفارشی» باشد اعمال می‌شود.' );

		$rows .= self::row(
			'حداکثر عدد (حالت سفارشی)',
			'<input type="number" name="wpmc_settings[max_num]" value="' . (int) $s['max_num'] . '" min="2" max="99" style="width:90px" dir="ltr">',
			'بزرگ‌ترین عددِ به‌کاررفته در مسائل.'
		);

		$rows .= self::row(
			'نمایش اعداد فارسی',
			'<label><input type="checkbox" name="wpmc_settings[persian_digits]" value="1" ' . checked( 1, (int) $s['persian_digits'], false ) . '> مسئله با اعداد فارسی نمایش داده شود</label>'
		);

		$rows .= self::row(
			'حداقل زمان پاسخ (ثانیه)',
			'<input type="number" name="wpmc_settings[min_time]" value="' . (int) $s['min_time'] . '" min="0" max="60" style="width:90px" dir="ltr">',
			'ارسال فرمِ سریع‌تر از این مدت (پس از نمایش مسئله) رد می‌شود؛ یکی از مهم‌ترین نشانه‌های ربات.'
		);

		$rows .= self::row(
			'حداکثر تلاش برای هر مسئله',
			'<input type="number" name="wpmc_settings[max_attempts]" value="' . (int) $s['max_attempts'] . '" min="1" max="10" style="width:90px" dir="ltr">',
			'پس از این تعداد جواب نادرست، آن مسئله باطل می‌شود و ربات مجبور به کسب چالش جدید می‌گردد.'
		);

		$rows .= self::row(
			'آستانه‌ی محدودسازی IP',
			'<input type="number" name="wpmc_settings[fail_threshold]" value="' . (int) $s['fail_threshold'] . '" min="1" max="100" style="width:90px" dir="ltr">',
			'بعد از این تعداد خطا در ۱۵ دقیقه، IP به‌صورت موقت قرنطینه می‌شود.'
		);

		$rows .= self::row(
			'مدت قرنطینه IP (دقیقه)',
			'<input type="number" name="wpmc_settings[lock_minutes]" value="' . (int) $s['lock_minutes'] . '" min="1" max="1440" style="width:90px" dir="ltr">'
		);

		$rows .= self::row(
			'حداکثر تولید کپچا (۱۰ دقیقه)',
			'<input type="number" name="wpmc_settings[gen_limit]" value="' . (int) $s['gen_limit'] . '" min="1" max="1000" style="width:110px" dir="ltr">',
			'سقف تولید مسائل از هر IP در بازه‌ی ۱۰ دقیقه (ضدِ سرباززدن و مصرف transient).'
		);

		$rows .= self::row(
			'مسدودسازی ربات‌های شناخته‌شده',
			'<label><input type="checkbox" name="wpmc_settings[block_bot_ua]" value="1" ' . checked( 1, (int) $s['block_bot_ua'], false ) . '> User-Agent‌های ربات (curl، python-requests، headless و…) رد شوند</label>'
		);

		$rows .= self::row(
			'اعتماد به سرور واسط (CDN)',
			'<label><input type="checkbox" name="wpmc_settings[trust_proxy]" value="1" ' . checked( 1, (int) $s['trust_proxy'], false ) . '> استفاده از X-Forwarded-For برای شناسایی IP</label>',
			'فقط وقتی روشن کنید که سایت پشت CDN / Reverse Proxy معتبر است؛ وگرنه ربات می‌تواند این سرور را جعل کند.'
		);

		$el_input = '<select name="wpmc_settings[elementor_scope]">'
			. '<option value="all" ' . selected( $s['elementor_scope'], 'all', false ) . '>همه‌ی فرم‌های المنتور (افزودن خودکار)</option>'
			. '<option value="selected" ' . selected( $s['elementor_scope'], 'selected', false ) . '>فقط فرم‌های انتخاب‌شده</option>'
			. '<option value="off" ' . selected( $s['elementor_scope'], 'off', false ) . '>برای فرم‌های المنتور غیرفعال</option>'
			. '</select>';
		if ( 'selected' === $s['elementor_scope'] ) {
			$el_input .= '<input type="text" name="wpmc_settings[elementor_form_ids]" value="' . esc_attr( $s['elementor_form_ids'] ) . '" style="width:100%;margin-top:8px" placeholder="مثلاً: 1a2b3c4d, 5e6f7a8b" dir="ltr">';
		}
		$rows .= self::row(
			'فرم‌های المنتور (Elementor Pro)',
			$el_input,
			'در حالت «همه»، کپچا به‌صورت خودکار به تمام فرم‌های المنتور تزریق می‌شود. در حالت «فقط انتخاب‌شده»، شناسه‌ی المانِ فرم (Element ID) یا نام فرم (Form Name در تب Advanced) را با کاما جدا وارد کنید.'
		);

		$rows .= self::row(
			'فرم ارسال نظرات',
			'<label><input type="checkbox" name="wpmc_settings[apply_comments]" value="1" ' . checked( 1, (int) $s['apply_comments'], false ) . '> محافظت از فرم کامنت</label>'
		);

		$rows .= self::row(
			'فرم ورود (wp-login.php)',
			'<label><input type="checkbox" name="wpmc_settings[apply_login]" value="1" ' . checked( 1, (int) $s['apply_login'], false ) . '> محافظت از فرم ورود کاربران</label>',
			'برای کاهش brute-force روی فرم ورود توصیه می‌شود.'
		);

		$rows .= self::row(
			'Contact Form 7',
			'<label><input type="checkbox" name="wpmc_settings[apply_cf7]" value="1" ' . checked( 1, (int) $s['apply_cf7'], false ) . '> فعال‌سازی تگ [wpmc]</label>',
			$cf7 ? 'در فرم‌های CF7 از تگ [wpmc] استفاده کنید.' : 'Contact Form 7 نصب نیست؛ پس از نصب آن این گزینه مؤثر می‌شود.'
		);

		$rows .= self::row(
			'ثبت رویدادها',
			'<label><input type="checkbox" name="wpmc_settings[log_events]" value="1" ' . checked( 1, (int) $s['log_events'], false ) . '> رویدادهای امنیتی در برگه‌ی «رویدادها» ثبت شوند</label>'
		);

		$rows .= self::row(
			'حالت عیب‌یابی',
			'<label><input type="checkbox" name="wpmc_settings[debug]" value="1" ' . checked( 1, (int) $s['debug'], false ) . '> جزئیات هر ارسال فرمِ المنتور را در رویدادها ثبت کن</label>',
			'برای عیب‌یابی: اگر فرم المنتوری مطابق انتظار رفتار نکرد، این گزینه را روشن کنید، یک بار فرم را ارسال کنید و در برگه‌ی «رویدادها» رکوردهای debug را بررسی نمایید.'
		);

		echo '<div class="wrap wpmc-admin">';
		echo '<h1>کپچای ریاضی امن</h1>';

		if ( ! $el_pro ) {
			echo '<div class="notice notice-warning inline"><p>برای محافظت از فرم‌های المنتور، افزونه‌ی <strong>Elementor Pro</strong> باید فعال باشد. سایر قابلیت‌ها (short code، نظرات، ورود، CF7) بدون آن نیز کار می‌کنند.</p></div>';
		}

		echo '<form method="post" action="options.php">';
		settings_fields( 'wpmc_group' );
		echo '<h2>تنظیمات</h2>';
		echo '<table class="form-table">' . $rows . '</table>';
		submit_button();
		echo '</form>';

		echo '<h2>پیش‌نمایش</h2>';
		echo WP_MC_Captcha::output(); // phpcs:ignore WordPress.Security.EscapeOutput -- خروجی این تابع escaped است.

		echo '</div>';
	}

	/**
	 * صفحه‌ی رویدادها.
	 */
	public static function render_logs() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$events = self::events();
		$labels = [
			'honeypot'      => 'فیلد دام (Honeypot) پر شده بود',
			'bot_ua'        => 'User-Agent شبیه ربات',
			'bad_token'     => 'توکن جعلی یا دستکاری‌شده',
			'expired'       => 'کپچای منقضی یا استفاده‌ی تکراری (Replay)',
			'too_fast'      => 'ارسال خیلی سریع (کمتر از حداقل زمان)',
			'missing'       => 'جواب کپچا خالی بود',
			'wrong'         => 'جواب نادرست',
			'wrong_final'   => 'جواب نادرست (به سقف تلاش رسید)',
			'gen_limit'     => 'سقف تولید کپچا IP پر شده',
			'ip_locked'     => 'IP در حالت قرنطینه بود',
			'ip_locked_out' => 'IP قرنطینه شد',
			'debug'         => 'ذخیره‌ی عیب‌یابی (جزئیات ارسال)',
		];

		echo '<div class="wrap wpmc-admin">';
		echo '<h1>رویدادهای امنیتی کپچا</h1>';

		if ( isset( $_GET['cleared'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success"><p>رویدادها پاک‌سازی شد.</p></div>';
		}

		echo '<form method="post" action="admin-post.php" style="margin-bottom:12px">';
		echo '<input type="hidden" name="action" value="wpmc_clear_log">';
		wp_nonce_field( 'wpmc_clear_log' );
		echo '<button type="submit" class="button button-secondary" onclick="return confirm(\'همه‌ی رویدادها پاک شود؟\');">پاک‌سازی رویدادها</button>';
		echo '</form>';

		if ( empty( $events ) ) {
			echo '<p>هنوز رویدادی ثبت نشده است.</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:980px">';
			echo '<thead><tr><th>زمان</th><th>IP</th><th>دلیل</th><th>منبع</th></tr></thead><tbody>';
			foreach ( array_slice( array_reverse( $events ), 0, 100 ) as $e ) {
				$reason  = isset( $labels[ $e['reason'] ] ) ? $labels[ $e['reason'] ] : $e['reason'];
				$ts      = isset( $e['t'] ) ? (int) $e['t'] : time();
				$ip      = isset( $e['ip'] ) ? (string) $e['ip'] : '';
				$ctx     = isset( $e['ctx'] ) ? (string) $e['ctx'] : '';
				echo '<tr>';
				echo '<td>' . esc_html( date_i18n( get_option( 'date_format' ) . ' H:i:s', $ts ) ) . '</td>';
				echo '<td dir="ltr">' . esc_html( $ip ) . '</td>';
				echo '<td>' . esc_html( $reason ) . '</td>';
				echo '<td dir="ltr">' . esc_html( $ctx ) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}

		echo '</div>';
	}
}

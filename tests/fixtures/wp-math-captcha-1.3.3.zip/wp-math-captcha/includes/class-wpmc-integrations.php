<?php
/**
 * یکپارچه‌سازی با بقیه‌ی فرم‌های وردپرس: نظرات، ورود و Contact Form 7.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_MC_Integrations {

	/**
	 * ثبت هوک‌ها (فقط برای بخش‌های فعال).
	 */
	public static function init() {
		if ( WP_MC_Core::get( 'apply_comments' ) ) {
			self::register_comments();
		}
		if ( WP_MC_Core::get( 'apply_login' ) ) {
			self::register_login();
		}
		if ( WP_MC_Core::get( 'apply_cf7' ) && function_exists( 'wpcf7_add_form_tag' ) ) {
			self::register_cf7();
		}
	}

	/* ------------------------------------------------------------------
	 * نظرات
	 * ------------------------------------------------------------------ */

	public static function register_comments() {
		// نقطه‌ی استاندارد وردپرس: بعد از textarea نظر و درست قبل از submit.
		// این هوک برای فرم نظر نوشته‌ها و review محصولات ووکامرس مشترک است.
		add_filter( 'comment_form_submit_field', [ __CLASS__, 'add_comment_field' ], 20, 2 );
		add_filter( 'preprocess_comment', [ __CLASS__, 'validate_comment' ] );
	}

	/**
	 * افزودن کپچا به فرم نظر.
	 *
	 * @param string $submit_field بخش دکمه‌ی ارسال.
	 * @param array  $args         تنظیمات فرم نظر.
	 * @return string
	 */
	public static function add_comment_field( $submit_field, $args = [] ) {
		return '<div class="comment-form-wpmc">' . WP_MC_Captcha::output() . '</div>' . $submit_field;
	}

	/**
	 * اعتبارسنجی قبل از درج نظر.
	 *
	 * @param array $commentdata داده‌ی نظر.
	 * @return array
	 */
	public static function validate_comment( $commentdata ) {
		// درخواست‌هایی که اصلاً از POST نیامده‌اند (مانند برخی مسیرهای
		// برنامه‌نویسی/REST) به این فرم HTML تعلق ندارند و این هوک به آن‌ها
		// دست نمی‌زند. اما هر POST کامنت باید کپچا داشته باشد؛ حذف فیلدها
		// نباید راه عبور ربات باشد.
		if ( empty( $_POST ) ) {
			return $commentdata;
		}
		$result = WP_MC_Captcha::verify(
			isset( $_POST['wpmc_answer'] ) ? wp_unslash( $_POST['wpmc_answer'] ) : '',
			isset( $_POST['wpmc_token'] ) ? wp_unslash( $_POST['wpmc_token'] ) : '',
			isset( $_POST['wpmc_website'] ) ? wp_unslash( $_POST['wpmc_website'] ) : '',
			'comment'
		);
		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', [ 'response' => 403 ] );
		}
		return $commentdata;
	}

	/* ------------------------------------------------------------------
	 * فرم ورود
	 * ------------------------------------------------------------------ */

	public static function register_login() {
		add_filter( 'login_form_login', [ __CLASS__, 'add_login_field' ] );
		add_filter( 'authenticate', [ __CLASS__, 'validate_login' ], 20, 3 );
	}

	/**
	 * افزودن کپچا به فرم ورود.
	 *
	 * @param string $form html فعلی.
	 * @return string
	 */
	public static function add_login_field( $form ) {
		return $form . '<p class="form-field wpmc-login">' . WP_MC_Captcha::output() . '</p>';
	}

	/**
	 * اعتبارسنجی هنگام احراز هویت.
	 *
	 * @param mixed  $security نتیجه.
	 * @param string $username نام کاربری.
	 * @param string $password گذرواژه.
	 * @return mixed
	 */
	public static function validate_login( $security, $username, $password ) {
		if ( empty( $_POST['wpmc_token'] ) && empty( $_POST['wpmc_answer'] ) ) {
			return $security;
		}
		$result = WP_MC_Captcha::verify(
			isset( $_POST['wpmc_answer'] ) ? wp_unslash( $_POST['wpmc_answer'] ) : '',
			isset( $_POST['wpmc_token'] ) ? wp_unslash( $_POST['wpmc_token'] ) : '',
			isset( $_POST['wpmc_website'] ) ? wp_unslash( $_POST['wpmc_website'] ) : '',
			'login'
		);
		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'wpmc_captcha_failed', $result->get_error_message() );
		}
		return $security;
	}

	/* ------------------------------------------------------------------
	 * Contact Form 7
	 * ------------------------------------------------------------------ */

	public static function register_cf7() {
		add_action( 'wpcf7_init', [ __CLASS__, 'cf7_form_tag' ] );
		add_action( 'wpcf7_validate_wpmc', [ __CLASS__, 'cf7_validate' ] );
	}

	/**
	 * ثبت تگ [wpmc] در CF7.
	 */
	public static function cf7_form_tag() {
		wpcf7_add_form_tag( 'wpmc', [ __CLASS__, 'cf7_render' ] );
	}

	/**
	 * خروجی تگ.
	 *
	 * @return string
	 */
	public static function cf7_render() {
		return '<div class="wpmc-cf7">' . WP_MC_Captcha::output(
			[
				'answer_name' => 'wpmc',
			]
		) . '</div>';
	}

	/**
	 * اعتبارسنجی تگ.
	 */
	public static function cf7_validate() {
		$result = WP_MC_Captcha::verify(
			isset( $_POST['wpmc'] ) ? wp_unslash( $_POST['wpmc'] ) : '',
			isset( $_POST['wpmc_token'] ) ? wp_unslash( $_POST['wpmc_token'] ) : '',
			isset( $_POST['wpmc_website'] ) ? wp_unslash( $_POST['wpmc_website'] ) : '',
			'cf7'
		);
		if ( is_wp_error( $result ) ) {
			wpcf7_add_validation_error( 'wpmc', $result->get_error_message() );
		}
	}
}

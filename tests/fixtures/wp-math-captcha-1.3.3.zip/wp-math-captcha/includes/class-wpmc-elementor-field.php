<?php
/**
 * فیلد اختصاصی «کپچای ریاضی» برای Elementor Pro.
 *
 * این فایل عمداً به‌صورت lazy-load و فقط بعد از در دسترس قرارگرفتن
 * Field_Base بارگذاری می‌شود؛ به این ترتیب ترتیب بارگذاری افزونه‌ها باعث
 * از دست رفتن هوک elementor_pro/forms/fields/register نمی‌شود.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
	return;
}

if ( class_exists( 'WP_MC_Elementor_Captcha_Field' ) ) {
	return;
}

class WP_MC_Elementor_Captcha_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {

	/**
	 * سازنده‌ی فیلد.
	 */
	public function __construct() {
		parent::__construct(
			'wpmc_math_captcha',
			__( 'کپچای ریاضی (امن)', 'wp-math-captcha' ),
			false,
			false
		);
	}

	/**
	 * کلید ماشینی فیلد.
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'wpmc_math_captcha';
	}

	/**
	 * نام نمایشی فیلد در پنل Elementor.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return __( 'کپچای ریاضی', 'wp-math-captcha' );
	}

	/**
	 * تنظیمات پیش‌فرض.
	 *
	 * در نسخه‌هایی که متد والد abstract است، نباید parent:: را صدا بزنیم.
	 *
	 * @return array
	 */
	public function get_default_settings(): array {
		$settings = [];
		try {
			$parent = get_parent_class( $this );
			$ref    = new \ReflectionMethod( $parent, 'get_default_settings' );
			if ( ! $ref->isAbstract() ) {
				$value = parent::get_default_settings();
				if ( is_array( $value ) ) {
					$settings = $value;
				}
			}
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CatchException.BaseThrow
			// تنظیمات پایه در این نسخه در دسترس نیست؛ از مقدار امن استفاده می‌کنیم.
		}
		$settings['label'] = __( 'کپچای ریاضی', 'wp-math-captcha' );
		return $settings;
	}

	/**
	 * رندر API فعلی Elementor Pro.
	 *
	 * @param array  $item       تنظیمات فیلد.
	 * @param int    $item_index شماره‌ی فیلد.
	 * @param object $form       شیء فرم.
	 */
	public function render( $item, $item_index, $form ): void {
		echo WP_MC_Captcha::output( [ 'prefix' => 'ff' ] ); // phpcs:ignore WordPress.Security.EscapeOutput -- خروجی توسط موتور افزونه escape شده است.
	}

	/**
	 * سازگاری با API قدیمی‌تر افزونه‌های Elementor Pro.
	 *
	 * @param array $field          داده‌ی فیلد.
	 * @param array $field_settings تنظیمات فیلد.
	 * @param array $form_fields    فیلدهای فرم.
	 */
	public function render_field( $field = [], $field_settings = [], $form_fields = [] ) {
		echo WP_MC_Captcha::output( [ 'prefix' => 'ff' ] ); // phpcs:ignore WordPress.Security.EscapeOutput -- خروجی توسط موتور افزونه escape شده است.
	}
}

<?php
/**
 * یکپارچه‌سازی با فرم‌های Elementor Pro.
 *
 * معماری اعتبارسنجی (چند لایه):
 *
 *  A) دروازه‌ی اصلی — اجرا می‌شود قبل از اینکه المنتور به درگاه ارسال برسد:
 *     A1) لایه‌ی «توری» روی admin_init: برای هر درخواست admin-ajax، اگر داده
 *         شکلِ ارسال فرمِ المنتور را داشته باشد (form_id + form_fields) یا نام
 *         اکشن با elementor_pro/ شروع شود و «form» در آن باشد، اعتبارسنجی
 *         می‌شود و در صورت نادرست‌بودن، درخواست با 400 پایان می‌یابد. این لایه
 *         به نام اکشن وابسته نیست؛ بنابراین حتی اگر المنتور در نسخه‌ای جدید نام
 *         اکشن AJAX را عوض کرده باشد، باز هم کار می‌کند.
 *     A2) هوک اختصاصی با اولویت ۱ روی wp_ajax_(nopriv_)elementor_pro/forms_handle_form
 *         (قبل از دستگیره‌ی خودِ المنتور با اولویت پیش‌فرض ۱۰).
 *
 *  B) لایه‌های پشتیبان از طریق هوک‌های خودِ المنتور (اگر در نسخه‌ی شما اجرا شوند):
 *     - elementor_pro/forms/validation: با add_error() خودِ المنتور خطا را به
 *       کاربر نشان می‌دهد و اکشن‌های فرم (ایمیل/ریدایرکت/ذخیره) اجرا نمی‌شود.
 *     - elementor_pro/forms/actions (نسخه‌های قدیمی‌تر) و
 *       فیلتر elementor_pro/forms/submission.
 *     هیچ‌یک از لایه‌های B دوباره اعتبارسنجی نمی‌کنند اگر دروازه‌ی اصلی همین
 *     درخواست را انجام داده باشد (چالش تک‌بار مصرفی است).
 *
 * تعیین محدوده‌ی فرم (حالت «فقط فرم‌های انتخاب‌شده») — هر یک کافی است:
 *  - شناسه‌ی المانِ فرم (Element ID) در لیست باشد، یا
 *  - نام فرم (Form Name) در لیست باشد (هم اگر در داده‌ی ارسال باشد و هم
 *    اگر از داده‌ی المان‌های صفحه در _elementor_data استخراج شود)، یا
 *  - داده‌ی ارسالی شامل فیلدهای کپچا (wpmc_*) باشد؛ یعنی فرم یا کپچای
 *    خودکار دارد یا فیلد «کپچای ریاضی» دستی در آن قرار گرفته است.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_MC_Elementor {

	/**
	 * آیا فیلد در پنل المنتور ثبت شد؟
	 *
	 * @var bool
	 */
	private static $field_registered = false;

	/**
	 * آیا ارسال فرمِ این درخواست از قبل پردازش شده است (دروازه یا هوک validation)؟
	 *
	 * @var bool
	 */
	private static $processed = false;

	/**
	 * فرمی که در این درخواست با موفقیت اعتبارسنجی شده (جلوگیری از اعتبارسنجی تکراری).
	 *
	 * @var string|null
	 */
	private static $gated_form = null;

	/**
	 * فرم‌هایی که در مسیر پشتیبان مردود شدند (برای فیلتر submission).
	 *
	 * @var array
	 */
	private static $blocked = [];

	/**
	 * cache نام‌های حل‌شده‌ی فرم در همین درخواست.
	 *
	 * @var array
	 */
	private static $name_cache = [];

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// این هوک‌ها را بدون وابستگی به ترتیب بارگذاری افزونه‌ها ثبت می‌کنیم.
		// Elementor Pro ممکن است بعد از این افزونه لود شود؛ در آن حالت هم
		// هوک رسمیِ ثبت فیلد در ادامه اجرا خواهد شد.

		// ثبت فیلد اختصاصی در پنل (هوک رسمیِ مستندات المنتور + نام‌های جایگزینِ
		// نسخه‌های دیگر تا در همه‌ی نسخه‌ها ثبت شود).
		add_action( 'elementor_pro/forms/fields/register', [ __CLASS__, 'register_field' ] );
		add_action( 'elementor_pro/forms/register_fields', [ __CLASS__, 'register_field' ] );
		add_action( 'elementor_pro/forms/fields', [ __CLASS__, 'register_field' ] );

		// (A1) دروازه — لایه‌ی توری: مستقل از نام اکشن، روی هر admin-ajax.
		add_action( 'admin_init', [ __CLASS__, 'gate_submission' ], 1 );

		// (A2) دروازه — لایه‌ی اختصاصی: قبل از handler خودِ المنتور.
		add_action( 'wp_ajax_elementor_pro/forms_handle_form', [ __CLASS__, 'gate_submission' ], 1 );
		add_action( 'wp_ajax_nopriv_elementor_pro/forms_handle_form', [ __CLASS__, 'gate_submission' ], 1 );

		// (B) لایه‌های پشتیبان.
		add_action( 'elementor_pro/forms/validation', [ __CLASS__, 'on_elementor_validation' ], 1, 2 );
		add_action( 'elementor_pro/forms/actions', [ __CLASS__, 'validate_form' ] );
		add_filter( 'elementor_pro/forms/submission', [ __CLASS__, 'filter_submission' ], 20, 2 );
	}

	/**
	 * ریست وضعیت درونی (صرفاً برای تست‌ها).
	 *
	 * @internal
	 */
	public static function reset_state() {
		self::$field_registered = false;
		self::$processed        = false;
		self::$gated_form       = null;
		self::$blocked          = [];
		self::$name_cache       = [];
	}

	/**
	 * ثبت فیلد اختصاصی در Manager فرم‌های المنتور.
	 *
	 * @param object $fields_manager fields manager.
	 */
	public static function register_field( $fields_manager ) {
		if ( self::$field_registered ) {
			return;
		}
		if ( ! is_object( $fields_manager ) || ! method_exists( $fields_manager, 'register' ) ) {
			return;
		}
		if ( ! class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
			return;
		}
		if ( ! class_exists( 'WP_MC_Elementor_Captcha_Field' ) ) {
			$field_file = __DIR__ . '/class-wpmc-elementor-field.php';
			if ( is_readable( $field_file ) ) {
				require_once $field_file;
			}
		}
		if ( ! class_exists( 'WP_MC_Elementor_Captcha_Field' ) ) {
			return;
		}
		try {
			$field = new WP_MC_Elementor_Captcha_Field();
			$fields_manager->register( $field );
			self::$field_registered = true;
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CatchException.BaseThrow
			error_log( 'WPMC: field registration failed: ' . $e->getMessage() );
		}
	}

	/**
	 * لیست شناسه‌ها/نام‌های تنظیم‌شده (حالت «فقط انتخاب‌شده»).
	 *
	 * @return array
	 */
	private static function scope_list() {
		return array_values(
			array_filter(
				array_map(
					'trim',
					explode( ',', (string) WP_MC_Core::get( 'elementor_form_ids', '' ) )
				)
			)
		);
	}

	/**
	 * آیا فرم در محدوده‌ی حفاظت است (با شناسه‌ی المان یا نام فرم)؟
	 *
	 * @param string $form_id   شناسه‌ی المان.
	 * @param string $form_name نام فرم (اگر در داده‌ی ارسال هست).
	 * @return bool
	 */
	public static function form_in_scope( $form_id, $form_name = '' ) {
		$form_id   = trim( (string) $form_id );
		$form_name = trim( (string) $form_name );
		$scope     = (string) WP_MC_Core::get( 'elementor_scope', 'all' );

		if ( 'off' === $scope ) {
			return false;
		}
		if ( 'all' === $scope ) {
			return true;
		}

		$ids = self::scope_list();
		if ( empty( $ids ) ) {
			return false;
		}

		foreach ( $ids as $id ) {
			if ( '' !== $form_id && hash_equals( $id, $form_id ) ) {
				return true;
			}
			if ( '' !== $form_name && hash_equals( $id, $form_name ) ) {
				return true;
			}
		}

		// تطبیق بر اساس «نام فرم» از داده‌ی المان‌های صفحه (تب Advanced).
		if ( '' !== $form_id ) {
			$resolved = self::resolve_form_name( $form_id );
			if ( '' !== $resolved ) {
				foreach ( $ids as $id ) {
					if ( hash_equals( $id, $resolved ) ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * خواندن «نام فرم» (settings.form_name) برای یک فرم المنتور از داده‌ی
	 * المان‌های صفحه‌ای که فرم در آن است (postmeta: _elementor_data).
	 *
	 * توضیح: داده‌ی ارسال AJAX معمولاً form_name را ارسال نمی‌کند؛ بنابراین
	 * در حالت «فقط انتخاب‌شده» وقتی کاربر نام فرم را وارد کرده باشد، آن را
	 * از خودِ صفحه استخراج می‌کنیم تا تطبیق بر اساس نام واقعاً کار کند.
	 *
	 * @param string $form_id شناسه‌ی المان.
	 * @return string
	 */
	private static function resolve_form_name( $form_id ) {
		$form_id = (string) $form_id;
		if ( '' === $form_id ) {
			return '';
		}
		if ( array_key_exists( $form_id, self::$name_cache ) ) {
			return self::$name_cache[ $form_id ];
		}

		$post_id = 0;
		foreach ( [ 'post_id', 'page_id' ] as $key ) {
			if ( isset( $_POST[ $key ] ) && '' !== (string) $_POST[ $key ] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$post_id = absint( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				break;
			}
		}

		$data = '';
		if ( $post_id ) {
			$meta = get_post_meta( $post_id, '_elementor_data', true );
			if ( is_string( $meta ) && '' !== $meta ) {
				$data = $meta;
			}
		}

		if ( '' === $data && $post_id && class_exists( '\Elementor\Plugin' ) ) {
			try {
				$doc = \Elementor\Plugin::$instance->documents->get( $post_id );
				if ( $doc && method_exists( $doc, 'get_data' ) ) {
					$decoded = $doc->get_data();
					if ( is_array( $decoded ) ) {
						$data = (string) wp_json_encode( $decoded );
					}
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CatchException.BaseThrow
				$data = '';
			}
		}

		$name = '';
		if ( '' !== $data ) {
			$json = json_decode( $data, true );
			if ( is_array( $json ) ) {
				$name = self::find_form_name( $json, $form_id );
			}
		}

		$name = trim( (string) $name );
		self::$name_cache[ $form_id ] = $name;
		return $name;
	}

	/**
	 * جستجوی ریکرسیوی المان از روی شناسه و خواندن settings.form_name.
	 *
	 * @param array  $tree    درخت المان‌ها.
	 * @param string $form_id شناسه‌ی المان.
	 * @return string
	 */
	private static function find_form_name( $tree, $form_id ) {
		foreach ( $tree as $node ) {
			if ( ! is_array( $node ) || ! isset( $node['id'] ) ) {
				continue;
			}
			if ( hash_equals( (string) $node['id'], $form_id ) ) {
				return isset( $node['settings']['form_name'] ) ? (string) $node['settings']['form_name'] : '';
			}
			if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) {
				$found = self::find_form_name( $node['elements'], $form_id );
				if ( '' !== $found ) {
					return $found;
				}
			}
		}
		return '';
	}

	/**
	 * آیا این ارسال باید تحت کپچا باشد؟
	 *
	 * @param string $form_id   شناسه‌ی المان.
	 * @param string $form_name نام فرم.
	 * @param array  $fields    فیلدهای ارسالی.
	 * @return bool
	 */
	private static function should_protect( $form_id, $form_name, $fields ) {
		if ( self::form_in_scope( $form_id, $form_name ) ) {
			return true;
		}
		// اگر فیلدهای کپچا در ارسال هست (تزریق خودکار یا فیلد دستی)، حتماً اعتبارسنجی می‌شود.
		return isset( $fields['wpmc_token'] )
			|| isset( $fields['wpmc_answer'] )
			|| isset( $fields['wpmc_website'] );
	}

	/**
	 * خواندن داده‌ی ارسال از $_POST (ساختار AJAX فرم‌های المنتور).
	 *
	 * @return array [ form_id, form_name, fields ]
	 */
	private static function submission_data() {
		$form_id   = isset( $_POST['form_id'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['form_id'] ) ) : '';
		$form_name = isset( $_POST['form_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['form_name'] ) ) : '';
		$fields    = ( isset( $_POST['form_fields'] ) && is_array( $_POST['form_fields'] ) ) ? wp_unslash( $_POST['form_fields'] ) : [];
		if ( ! is_array( $fields ) ) {
			$fields = [];
		}
		return [ $form_id, $form_name, $fields ];
	}

	/**
	 * آیا این درخواست «شکلِ» ارسال یک فرم Elementor Pro را دارد؟ (مستقل از نام اکشن)
	 *
	 * @return bool
	 */
	private static function is_form_submission() {
		$action = isset( $_POST['action'] ) ? (string) $_POST['action'] : '';
		if ( '' !== $action && 0 === strpos( $action, 'elementor_pro/' ) && false !== stripos( $action, 'form' ) ) {
			return true;
		}
		// برای اکشن‌های ناشناخته، وجود post_id هم لازم است؛ این همان payload
		// واقعی Elementor Pro است و جلوی false-positive برای فرم‌های سایر
		// افزونه‌ها با کلیدهای عمومی form_id/form_fields را می‌گیرد.
		return isset( $_POST['post_id'] )
			&& absint( $_POST['post_id'] ) > 0
			&& isset( $_POST['form_id'] )
			&& '' !== (string) $_POST['form_id']
			&& isset( $_POST['form_fields'] )
			&& is_array( $_POST['form_fields'] );
	}

	/**
	 * اعتبارسنجی کپچا از روی فیلدها.
	 *
	 * @param array  $fields  فیلدهای فرم.
	 * @param string $form_id شناسه‌ی المان (برای لاگ).
	 * @return true|WP_Error
	 */
	private static function do_verify( $fields, $form_id ) {
		return WP_MC_Captcha::verify(
			isset( $fields['wpmc_answer'] ) ? $fields['wpmc_answer'] : '',
			isset( $fields['wpmc_token'] ) ? $fields['wpmc_token'] : '',
			isset( $fields['wpmc_website'] ) ? $fields['wpmc_website'] : '',
			'elementor:' . $form_id
		);
	}

	/**
	 * ثبت جزئیات عیب‌یابی (فقط وقتی «حالت عیب‌یابی» روشن است).
	 *
	 * @param string $source   منبع (gate / elementor-validation / fallback).
	 * @param string $decision تصمیم (protect / pass).
	 * @param string $form_id  شناسه‌ی المان.
	 * @param string $form_name نام فرم از POST.
	 * @param array  $fields   فیلدها.
	 */
	private static function debug_log( $source, $decision, $form_id, $form_name, $fields ) {
		if ( ! WP_MC_Core::get( 'debug' ) ) {
			return;
		}
		WP_MC_Core::log_event(
			'debug',
			sprintf(
				'v%s %s %s form_id=%s post_name=%s resolved_name=%s scope=%s list=%s has_fields=%s',
				defined( 'WPMC_VERSION' ) ? WPMC_VERSION : '?',
				$source,
				$decision,
				$form_id,
				$form_name,
				self::resolve_form_name( $form_id ),
				(string) WP_MC_Core::get( 'elementor_scope', 'all' ),
				(string) WP_MC_Core::get( 'elementor_form_ids', '' ),
				isset( $fields['wpmc_token'] ) ? 'yes' : 'no'
			)
		);
	}

	/**
	 * (A) دروازه‌ی اصلی: قبل از هر چیز دیگری در درخواست ارسال فرم.
	 *
	 * اگر کپچا نادرست/مفقود باشد، پاسخ 400 ارسال و درخواست پایان می‌یابد؛
	 * در صورت موفقیت، چالش مصرف شده و اجرای المنتور ادامه می‌یابد.
	 *
	 * این تابع هم از توری admin_init (A1) و هم از هوک اختصاصی اکشن (A2)
	 * صدا زده می‌شود؛ پرچم $processed از پردازش دوتایی در یک درخواست جلوگیری می‌کند.
	 */
	public static function gate_submission() {
		// این دروازه فقط وقتی فعال است که Elementor Pro واقعاً بارگذاری شده
		// باشد؛ بنابراین AJAX سایر افزونه‌ها در سایت بدون Elementor تحت تأثیر
		// قرار نمی‌گیرد.
		if ( ! ( defined( 'ELEMENTOR_PRO_VERSION' ) || class_exists( '\\ElementorPro\\Plugin' ) ) ) {
			return;
		}
		if ( self::$processed ) {
			return;
		}
		if ( ! self::is_form_submission() ) {
			return; // درخواست فرمِ المنتور نیست؛ کاری انجام نده.
		}
		self::$processed = true;

		list( $form_id, $form_name, $fields ) = self::submission_data();

		if ( '' === $form_id ) {
			self::debug_log( 'gate', 'pass(no-form_id)', '', $form_name, $fields );
			return;
		}

		$protect = self::should_protect( $form_id, $form_name, $fields );
		self::debug_log( 'gate', $protect ? 'protect' : 'pass', $form_id, $form_name, $fields );

		if ( ! $protect ) {
			return; // فرم خارج از محدوده: اجازه‌ی ادامه به المنتور.
		}

		self::$gated_form = $form_id;

		$result = self::do_verify( $fields, $form_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				[
					'code'    => 400,
					'message' => $result->get_error_message(),
				],
				400
			);
		}
	}

	/**
	 * (B-1) لایه‌ی پشتیبان: هوک elementor_pro/forms/validation المنتور.
	 *
	 * اگر دروازه‌ی اصلی در این درخواست اجرا نشده باشد (مثلاً ارسال از مسیر دیگری)،
	 * همین‌جا اعتبارسنجی می‌شود و خطا از طریق add_error به دستِ کاربر می‌رسد؛
	 * خودِ المنتور در صورت خطای validation اکشن‌های فرم را اجرا نمی‌کند.
	 *
	 * @param object|null $record        فرم‌ریکورد المنتور.
	 * @param object|null $ajax_handler دستیار پاسخ AJAX المنتور.
	 */
	public static function on_elementor_validation( $record = null, $ajax_handler = null ) {
		if ( self::$processed ) {
			return; // دروازه‌ی اصلی همین درخواست را از قبل پردازش کرده است.
		}

		list( $form_id, $form_name, $fields ) = self::submission_data();
		if ( '' === $form_id ) {
			return;
		}
		if ( ! self::should_protect( $form_id, $form_name, $fields ) ) {
			return;
		}

		self::$processed  = true;
		self::$gated_form = $form_id;
		self::debug_log( 'elementor-validation', 'protect', $form_id, $form_name, $fields );

		$result = self::do_verify( $fields, $form_id );
		if ( is_wp_error( $result ) ) {
			$handled = false;
			if ( is_object( $ajax_handler ) && method_exists( $ajax_handler, 'add_error' ) ) {
				try {
					$ajax_handler->add_error( 'wpmc_captcha', $result->get_error_message() );
					$handled = true;
				} catch ( \Throwable $e ) { // phpcs:ignore Generic.CatchException.BaseThrow
					$handled = false;
				}
			}
			if ( ! $handled ) {
				self::$blocked[ $form_id ] = $result;
			}
		}
	}

	/**
	 * (B-2) مسیر پشتیبان قدیمی: هوک elementor_pro/forms/actions.
	 *
	 * @param array $data داده‌ی فرم.
	 */
	public static function validate_form( $data ) {
		if ( self::$processed ) {
			return;
		}
		if ( ! is_array( $data ) || empty( $data['form_id'] ) ) {
			return;
		}
		$form_id = (string) $data['form_id'];

		// اگر دروازه‌ی اصلی همین فرم را در این درخواست دیده، تکرار نمی‌کنیم
		// (چالش مصرف شده و دوباره خواندن منجر به خطای کاذب می‌شود).
		if ( self::$gated_form === $form_id ) {
			return;
		}
		self::$blocked = [];

		$form_name = isset( $data['form_name'] ) ? (string) $data['form_name'] : '';
		$fields    = ( isset( $data['form_fields'] ) && is_array( $data['form_fields'] ) ) ? $data['form_fields'] : [];
		if ( ! is_array( $fields ) ) {
			$fields = [];
		}

		if ( ! self::should_protect( $form_id, $form_name, $fields ) ) {
			return;
		}

		self::$processed  = true;
		self::$gated_form = $form_id;
		self::debug_log( 'fallback', 'protect', $form_id, $form_name, $fields );

		$result = self::do_verify( $fields, $form_id );
		if ( is_wp_error( $result ) ) {
			self::$blocked[ $form_id ] = $result;
		}
	}

	/**
	 * (B-3) تبدیل پاسخ موفق به خطا در مسیر پشتیبان.
	 *
	 * @param array      $response پاسخ پیش‌فرض.
	 * @param array|null $data     داده‌ی فرم.
	 * @return array
	 */
	public static function filter_submission( $response = [], $data = null ) {
		if ( ! is_array( $response ) ) {
			$response = [];
		}
		if ( empty( self::$blocked ) ) {
			return $response;
		}
		$form_id = ( is_array( $data ) && isset( $data['form_id'] ) ) ? (string) $data['form_id'] : '';
		$err     = ( '' !== $form_id && isset( self::$blocked[ $form_id ] ) ) ? self::$blocked[ $form_id ] : null;
		if ( null === $err && '' === $form_id ) {
			// نسخه‌ای که در فیلتر form_id نمی‌فرستد: همان‌یک فرمِ این درخواست.
			$err = reset( self::$blocked );
		}
		if ( $err instanceof WP_Error ) {
			$response['code']    = 400;
			$response['message'] = $err->get_error_message();
			self::$blocked       = [];
		}
		return $response;
	}
}

/**
 * کلاس فیلد Elementor Pro در فایل جداگانه و به‌صورت lazy-load قرار دارد.
 *
 * @see WP_MC_Elementor::register_field()
 */

<?php
/**
 * موتور کپچای ریاضی: تولید چالش، توکن امضاشده، اعتبارسنجی و خروجی HTML.
 *
 * مدل امنیتی:
 *  - جواب هیچ‌وقت به سمت کاربر ارسال نمی‌شود؛ فقط در transient سرور نگهداری می‌شود.
 *  - توکن ۱۲۸ بیت تصادفی + امضای HMAC-SHA256 با salt اختصاصی سایت (جلوگیری از جعل/تخمین).
 *  - تک‌بار مصرفی (Single-use): بعد از ارسال موفق، چالش حذف می‌شود (ضد Replay).
 *  - سقف تلاش برای هر چالش + شمارش خطا به ازای هر IP + قرنطینه IP.
 *  - حداقل زمان پاسخ (ضد ارسال آنی ربات‌ها).
 *  - فیلد دام Honeypot (فقط ربات‌ها آن را پر می‌کنند).
 *  - مسدودسازی User-Agent‌های شناخته‌شده رباتی (اختیاری).
 *  - سقف تولید چالش به ازای هر IP (ضد سرباززدن).
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_MC_Captcha {

	/**
	 * پیشوند transient چالش‌ها.
	 */
	const TT_CHALLENGE = 'wpmc_ch_';

	/**
	 * عمر چالش (ثانیه).
	 */
	const TTL = 300;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_shortcode( 'math_captcha', [ __CLASS__, 'shortcode' ] );
		add_shortcode( 'wpmc_captcha', [ __CLASS__, 'shortcode' ] );

		add_action( 'wp_ajax_wpmc_refresh', [ __CLASS__, 'ajax_refresh' ] );
		add_action( 'wp_ajax_nopriv_wpmc_refresh', [ __CLASS__, 'ajax_refresh' ] );
		add_action( 'wp_ajax_wpmc_render', [ __CLASS__, 'ajax_render' ] );
		add_action( 'wp_ajax_nopriv_wpmc_render', [ __CLASS__, 'ajax_render' ] );

		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'assets' ] );
	}

	/**
	 * Shortcode عمومی.
	 *
	 * @return string
	 */
	public static function shortcode() {
		return self::output();
	}

	/**
	 * بارگذاری داروها.
	 */
	public static function assets() {
		wp_enqueue_style( 'wpmc', WPMC_URL . 'assets/wpmc.css', [], WPMC_VERSION );
		wp_enqueue_script( 'wpmc', WPMC_URL . 'assets/wpmc.js', [], WPMC_VERSION, true );
		wp_localize_script(
			'wpmc',
			'WPMC',
			[
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wpmc_frontend' ),
				'version' => WPMC_VERSION,
				'debug'   => (bool) WP_MC_Core::get( 'debug', 0 ),
				'scope'   => WP_MC_Core::get( 'elementor_scope', 'all' ),
				'formIds' => array_values(
					array_filter(
						array_map(
							'trim',
							explode( ',', (string) WP_MC_Core::get( 'elementor_form_ids', '' ) )
						)
					)
				),
				'i18n'    => [
					'load'  => __( 'در حال بارگذاری…', 'wp-math-captcha' ),
					'err'   => __( 'کپچا بارگذاری نشد. لطفاً صفحه را نوساری کنید.', 'wp-math-captcha' ),
					'rate'  => __( 'تلاش‌های شما زیاد است؛ چند لحظه صبر کنید.', 'wp-math-captcha' ),
					'empty' => __( 'جواب کپچا را وارد کنید.', 'wp-math-captcha' ),
				],
			]
		);
	}

	/* ------------------------------------------------------------------
	 * تولید چالش
	 * ------------------------------------------------------------------ */

	/**
	 * عملیات و سقف عدد بر اساس سطح دشواری.
	 *
	 * @return array [ array $ops, int $max ]
	 */
	private static function params() {
		$d = WP_MC_Core::get( 'difficulty', 'medium' );
		if ( 'easy' === $d ) {
			return [ [ '+', '-' ], 9 ];
		}
		if ( 'hard' === $d ) {
			return [ [ '+', '-', 'x' ], 12 ];
		}
		if ( 'custom' === $d ) {
			$ops = array_values(
				array_intersect( (array) WP_MC_Core::get( 'ops', [ '+', '-' ] ), [ '+', '-', 'x' ] )
			);
			if ( empty( $ops ) ) {
				$ops = [ '+' ];
			}
			$max = max( 2, min( 99, (int) WP_MC_Core::get( 'max_num', 20 ) ) );
			return [ $ops, $max ];
		}
		return [ [ '+', '-' ], 20 ];
	}

	/**
	 * ساخت چالش جدید + توکن امضاشده.
	 *
	 * @return array|WP_Error [ a, b, op, ans, token ]
	 */
	public static function new_challenge() {
		$ip    = WP_MC_Core::ip();
		$limit = max( 1, (int) WP_MC_Core::get( 'gen_limit', 300 ) );
		$key   = 'wpmc_gen_' . md5( $ip );
		$count = (int) get_transient( $key );

		if ( $count >= $limit ) {
			WP_MC_Core::log_event( 'gen_limit', 'challenge' );
			return new WP_Error( 'gen_limit', __( 'کپچا در حال حاضر در دسترس نیست؛ لطفاً کمی بعد دوباره تلاش کنید.', 'wp-math-captcha' ) );
		}
		set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );

		list( $ops, $max ) = self::params();
		$op                = $ops[ array_rand( $ops ) ];

		if ( 'x' === $op ) {
			$a   = random_int( 2, min( 12, max( 2, $max ) ) );
			$b   = random_int( 2, min( 12, max( 2, $max ) ) );
			$ans = $a * $b;
		} else {
			$a   = random_int( 0, $max );
			$b   = random_int( 0, $max );
			if ( '-' === $op && $b > $a ) {
				list( $a, $b ) = [ $b, $a ];
			}
			$ans = ( '+' === $op ) ? $a + $b : $a - $b;
		}

		$id = bin2hex( random_bytes( 16 ) );

		set_transient(
			self::TT_CHALLENGE . $id,
			[
				'a'        => $a,
				'b'        => $b,
				'op'       => $op,
				'ans'      => $ans,
				'created'  => time(),
				'attempts' => 0,
			],
			self::TTL
		);

		return [
			'a'     => $a,
			'b'     => $b,
			'op'    => $op,
			'ans'   => $ans,
			'token' => $id . '.' . hash_hmac( 'sha256', $id, WP_MC_Core::key() ),
		];
	}

	/* ------------------------------------------------------------------
	 * اعتبارسنجی
	 * ------------------------------------------------------------------ */

	/**
	 * پیام عمومی برای خطاهایی که نباید دلیلشان لو برفت.
	 *
	 * @return string
	 */
	public static function msg_generic() {
		return __( 'کپچا منقضی شده یا نادرست است؛ روی دکمه‌ی ↻ بزنید تا مسئله‌ی جدیدی بگیرید.', 'wp-math-captcha' );
	}

	/**
	 * نرمال‌سازی جواب (اعداد فارسی/عربی به انگلیسی، حذف نویز).
	 *
	 * @param mixed $v ورودی.
	 * @return string
	 */
	public static function normalize( $v ) {
		$v = (string) $v;
		$map = [
			'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
			'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
			'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
			'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			'−' => '-',
		];
		foreach ( $map as $from => $to ) {
			$v = str_replace( $from, $to, $v );
		}
		$v   = trim( $v );
		$out = preg_replace( '/[^0-9-]/', '', $v );
		return is_string( $out ) ? $out : '';
	}

	/**
	 * تبدیل عدد به ارقام فارسی.
	 *
	 * @param int|string $num عدد.
	 * @return string
	 */
	public static function to_persian( $num ) {
		$map = [
			'0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
			'5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
		];
		$str = (string) $num;
		$out = '';
		for ( $i = 0, $len = strlen( $str ); $i < $len; $i++ ) {
			$c        = $str[ $i ];
			$out     .= isset( $map[ $c ] ) ? $map[ $c ] : ( '-' === $c ? '−' : $c );
		}
		return $out;
	}

	/**
	 * آیا IP در حالت قرنطینه است؟
	 *
	 * @param string $ip آدرس.
	 * @return bool
	 */
	public static function is_ip_locked( $ip ) {
		return (bool) get_transient( 'wpmc_lock_' . md5( $ip ) );
	}

	/**
	 * شمارش یک خطا؛ در صورت عبور از آستانه، IP قرنطینه می‌شود.
	 *
	 * @param string $ip      آدرس.
	 * @param string $reason  کد دلیل.
	 * @param string $context منبع.
	 */
	public static function count_fail( $ip, $reason, $context = '' ) {
		WP_MC_Core::log_event( $reason, $context );

		$key   = 'wpmc_fail_' . md5( $ip );
		$count = (int) get_transient( $key );
		$count++;
		set_transient( $key, $count, 15 * MINUTE_IN_SECONDS );

		$threshold = max( 1, (int) WP_MC_Core::get( 'fail_threshold', 8 ) );
		if ( $count >= $threshold ) {
			$minutes  = max( 1, (int) WP_MC_Core::get( 'lock_minutes', 30 ) );
			set_transient( 'wpmc_lock_' . md5( $ip ), time(), $minutes * MINUTE_IN_SECONDS );
			delete_transient( $key );
			WP_MC_Core::log_event( 'ip_locked_out', $context );
		}
	}

	/**
	 * آیا User-Agent شبیه ربات است؟
	 *
	 * @param string $ua رشته.
	 * @return bool
	 */
	public static function is_bot_ua( $ua ) {
		$ua = strtolower( trim( (string) $ua ) );
		if ( '' === $ua ) {
			return true;
		}
		$patterns = [
			'curl/', 'wget/', 'python-requests', 'python-urllib', 'python/', 'aiohttp',
			'go-http-client', 'libwww-perl', 'lwp::simple', 'java/', 'httpclient', 'apache-httpclient',
			'headless', 'phantomjs', 'selenium', 'playwright', 'puppeteer',
			'scrapy', 'httpunit', 'requests-library', 'nikto', 'sqlmap', 'nmap ', 'masscan', 'zgrab', 'nuclei',
			'bot', 'spider', 'crawler', 'slurp',
		];
		foreach ( $patterns as $p ) {
			if ( false !== strpos( $ua, $p ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * اعتبارسنجی نهایی کپچا.
	 *
	 * @param mixed  $answer   جواب کاربر.
	 * @param mixed  $token    توکن امضاشده (فیلد مخفی).
	 * @param mixed  $honeypot مقدار فیلد دام.
	 * @param string $context  نام فرم/منبع (برای لاگ).
	 * @return true|WP_Error
	 */
	public static function verify( $answer, $token, $honeypot = '', $context = 'unknown' ) {
		$ip = WP_MC_Core::ip();

		// ۱) فیلد دام: انسان آن را نمی‌بیند و نمی‌پراند.
		if ( '' !== trim( (string) $honeypot ) ) {
			self::count_fail( $ip, 'honeypot', $context );
			return new WP_Error( 'honeypot', __( 'اطلاعات ارسال‌شده نادرست بود؛ لطفاً دوباره تلاش کنید.', 'wp-math-captcha' ) );
		}

		// ۲) IP قرنطینه‌شده.
		if ( self::is_ip_locked( $ip ) ) {
			WP_MC_Core::log_event( 'ip_locked', $context );
			return new WP_Error( 'ip_locked', __( 'تلاش‌های ناموفق زیادی از این آدرس ثبت شده است؛ چند دقیقه دیگر دوباره امتحان کنید.', 'wp-math-captcha' ) );
		}

		// ۳) ربات‌های شناخته‌شده.
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		if ( WP_MC_Core::get( 'block_bot_ua' ) && self::is_bot_ua( $ua ) ) {
			self::count_fail( $ip, 'bot_ua', $context );
			return new WP_Error( 'bot_ua', __( 'کپچا را صحیح وارد نکردید.', 'wp-math-captcha' ) );
		}

		$token  = trim( (string) $token );
		$answer = (string) $answer;

		// ۴) جواب خالی (بدون حسابِ خطا؛ احتمالاً اشتباه انسانی).
		if ( '' === trim( $answer ) && '' !== $token ) {
			return new WP_Error( 'missing', __( 'جواب کپچا را وارد کنید.', 'wp-math-captcha' ) );
		}

		// ۵) ساختار و امضای توکن.
		$parts = explode( '.', $token );
		if ( count( $parts ) !== 2 || '' === $parts[0] || '' === $parts[1] ) {
			self::count_fail( $ip, 'bad_token', $context );
			return new WP_Error( 'bad_token', self::msg_generic() );
		}
		if ( ! hash_equals( hash_hmac( 'sha256', $parts[0], WP_MC_Core::key() ), $parts[1] ) ) {
			self::count_fail( $ip, 'bad_token', $context );
			return new WP_Error( 'bad_token', self::msg_generic() );
		}

		// ۶) چالش (تک‌بار مصرفی؛ در نبودش = منقضی یا Replay).
		$challenge = get_transient( self::TT_CHALLENGE . $parts[0] );
		if ( ! is_array( $challenge ) || ! isset( $challenge['ans'] ) ) {
			self::count_fail( $ip, 'expired', $context );
			return new WP_Error( 'expired', self::msg_generic() );
		}

		// ۷) حداقل زمان پاسخ.
		$elapsed  = time() - (int) $challenge['created'];
		$min_time = max( 0, (int) WP_MC_Core::get( 'min_time', 3 ) );
		if ( $elapsed < $min_time ) {
			self::count_fail( $ip, 'too_fast', $context );
			return new WP_Error( 'too_fast', __( 'هنوز زود است! لطفاً چند ثانیه صبر کنید و دوباره تلاش کنید.', 'wp-math-captcha' ) );
		}

		// ۸) مقایسه‌ی امن جواب.
		if ( hash_equals( self::normalize( (string) $challenge['ans'] ), self::normalize( $answer ) ) ) {
			delete_transient( self::TT_CHALLENGE . $parts[0] );
			return true;
		}

		// ۹) جواب نادرست: افزایش شمارنده‌ی تلاش.
		$max_attempts       = max( 1, (int) WP_MC_Core::get( 'max_attempts', 3 ) );
		$challenge['attempts'] = (int) ( isset( $challenge['attempts'] ) ? $challenge['attempts'] : 0 ) + 1;

		if ( $challenge['attempts'] >= $max_attempts ) {
			delete_transient( self::TT_CHALLENGE . $parts[0] );
			self::count_fail( $ip, 'wrong_final', $context );
			return new WP_Error( 'wrong_final', __( 'تلاش‌های نادرست زیادی داشتید؛ روی ↻ بزنید تا مسئله‌ی جدیدی بگیرید.', 'wp-math-captcha' ) );
		}

		$ttl = max( 30, self::TTL - max( 0, $elapsed ) );
		set_transient( self::TT_CHALLENGE . $parts[0], $challenge, $ttl );
		self::count_fail( $ip, 'wrong', $context );
		return new WP_Error( 'wrong', __( 'جواب نادرست است؛ دوباره تلاش کنید.', 'wp-math-captcha' ) );
	}

	/* ------------------------------------------------------------------
	 * خروجی HTML
	 * ------------------------------------------------------------------ */

	/**
	 * الگوی نویز SVG برای سخت‌تر خواندن مسئله توسط OCR.
	 *
	 * @return string
	 */
	private static function noise_svg() {
		$paths = '';
		for ( $i = 0; $i < 3; $i++ ) {
			$paths .= 'M0,' . random_int( 8, 34 ) . ' C 40,' . random_int( 8, 34 ) . ' 90,' . random_int( 8, 34 ) . ' 150,' . random_int( 8, 34 );
		}
		$dots = '';
		for ( $i = 0; $i < 14; $i++ ) {
			$dots .= '<circle cx="' . random_int( 2, 148 ) . '" cy="' . random_int( 2, 38 ) . '" r="' . random_int( 1, 2 ) . '"/>';
		}
		return '<svg class="wpmc-noise" viewBox="0 0 150 40" preserveAspectRatio="none" aria-hidden="true">'
			. '<g stroke="#8b98a9" stroke-width="1" fill="none">' . $paths . '</g>'
			. '<g fill="#aeb9c6">' . $dots . '</g></svg>';
	}

	/**
	 * ساخت نام فیلد با پیشوند فرم (مثلاً form_fields[x]).
	 *
	 * @param string $prefix '' یا 'ff'.
	 * @param string $name   نام فیلد.
	 * @return string
	 */
	private static function field_name( $prefix, $name ) {
		return 'ff' === $prefix ? 'form_fields[' . $name . ']' : $name;
	}

	/**
	 * ساخت HTML کامل کپچا.
	 *
	 * @param array $ch    خروجی new_challenge().
	 * @param array $opts  [ prefix => ''|'ff', answer_name, token_name, hp_name ].
	 * @return string
	 */
	public static function build_html( $ch, $opts = [] ) {
		$prefix      = ( isset( $opts['prefix'] ) && 'ff' === $opts['prefix'] ) ? 'ff' : '';
		$answer_name = isset( $opts['answer_name'] ) ? (string) $opts['answer_name'] : 'wpmc_answer';
		$token_name  = isset( $opts['token_name'] ) ? (string) $opts['token_name'] : 'wpmc_token';
		$hp_name     = isset( $opts['hp_name'] ) ? (string) $opts['hp_name'] : 'wpmc_website';

		$persian = (bool) WP_MC_Core::get( 'persian_digits', 1 );
		$num     = function ( $n ) use ( $persian ) {
			return $persian ? self::to_persian( $n ) : (string) $n;
		};

		$op_display = [ '+' => '+', '-' => '−', 'x' => '×' ][ $ch['op'] ];
		$chars      = [ $num( $ch['a'] ), $op_display, $num( $ch['b'] ), '=', $persian ? '؟' : '?' ];

		$spans = '';
		foreach ( $chars as $i => $c ) {
			$rot = random_int( -8, 8 );
			$ty  = random_int( -2, 2 );
			$fs  = random_int( 24, 32 );
			$fw  = in_array( $i, [ 0, 2 ], true ) ? random_int( 500, 800 ) : 600;
			$cls = in_array( $c, [ '+', '−', '×', '=' ], true )
				? ' class="wpmc-op"'
				: ( ( '?' === $c || '؟' === $c ) ? ' class="wpmc-q"' : '' );
			$spans .= '<span' . $cls . ' style="transform:rotate(' . $rot . 'deg) translateY(' . $ty . 'px);font-size:' . $fs . 'px;font-weight:' . $fw . ';">' . esc_html( $c ) . '</span>';
		}

		$op_for_label = ( 'x' === $ch['op'] ) ? '*' : $ch['op'];
		$label        = $ch['a'] . ' ' . $op_for_label . ' ' . $ch['b'] . ' = ?';

		$html  = '<div class="wpmc-captcha" data-nonce="' . esc_attr( wp_create_nonce( 'wpmc_frontend' ) ) . '" data-prefix="' . esc_attr( $prefix ? 'ff' : '' ) . '">';
		$html .= '<div class="wpmc-challenge">';
		$html .= '<div class="wpmc-equation" dir="ltr" role="img" aria-label="' . esc_attr( $label ) . '">' . $spans . '</div>';
		$html .= self::noise_svg();
		$html .= '</div>';

		$html .= '<div class="wpmc-controls">';
		$html .= '<input type="text" class="wpmc-input" name="' . esc_attr( self::field_name( $prefix, $answer_name ) ) . '" inputmode="numeric" autocomplete="off" spellcheck="false" maxlength="5" placeholder="' . esc_attr__( 'جواب', 'wp-math-captcha' ) . '">';
		$html .= '<button type="button" class="wpmc-refresh" title="' . esc_attr__( 'مسئله‌ی جدید', 'wp-math-captcha' ) . '" aria-label="' . esc_attr__( 'مسئله‌ی جدید', 'wp-math-captcha' ) . '">&#8635;</button>';
		$html .= '</div>';

		$html .= '<input type="hidden" class="wpmc-token" name="' . esc_attr( self::field_name( $prefix, $token_name ) ) . '" value="' . esc_attr( $ch['token'] ) . '">';

		// فیلد دام: برای انسان نامرئی است، برای ربات در مسیر فرم.
		$html .= '<div class="wpmc-hp" aria-hidden="true"><label>' . esc_html__( 'آدرس وب‌سایت شما', 'wp-math-captcha' ) . ' <input type="text" name="' . esc_attr( self::field_name( $prefix, $hp_name ) ) . '" tabindex="-1" autocomplete="off"></label></div>';

		$html .= '<noscript><div class="wpmc-error">' . esc_html__( 'اگر کپچا باطل شد یا تازه‌سازی نشد، صفحه را نوسازی کنید.', 'wp-math-captcha' ) . '</div></noscript>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * تولید چالش + خروجی HTML (درگاه عمومی رندر).
	 *
	 * @param array $opts همان opts خروجی build_html().
	 * @return string
	 */
	public static function output( $opts = [] ) {
		if ( ! WP_MC_Core::get( 'enabled', 1 ) ) {
			return '';
		}
		$ch = self::new_challenge();
		if ( is_wp_error( $ch ) ) {
			return '<div class="wpmc-captcha"><div class="wpmc-error">' . esc_html( $ch->get_error_message() ) . '</div></div>';
		}
		return self::build_html( $ch, $opts );
	}

	/* ------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------ */

	/**
	 * نوسازی چالش (با nonce؛ سقف ۱۰ بار در دقیقه به ازای IP).
	 */
	public static function ajax_refresh() {
		check_ajax_referer( 'wpmc_frontend', 'nonce' );

		$ip   = WP_MC_Core::ip();
		$rk   = 'wpmc_re_' . md5( $ip );
		$rc   = (int) get_transient( $rk );
		if ( $rc >= 10 ) {
			wp_send_json_error( [ 'error' => 'rate' ], 429 );
		}
		set_transient( $rk, $rc + 1, MINUTE_IN_SECONDS );

		$prefix = ( isset( $_POST['prefix'] ) && 'ff' === $_POST['prefix'] ) ? 'ff' : '';
		$ch     = self::new_challenge();
		if ( is_wp_error( $ch ) ) {
			wp_send_json_error( [ 'error' => $ch->get_error_code(), 'msg' => $ch->get_error_message() ] );
		}
		wp_send_json_success(
			[
				'html'  => self::build_html( $ch, [ 'prefix' => $prefix ] ),
				'nonce' => wp_create_nonce( 'wpmc_frontend' ),
			]
		);
	}

	/**
	 * رندر اولیه برای تزریق خودکار به فرم‌های المنتور.
	 *
	 * این درگاه حساس نیست (فقط مسئله‌ی تصادفی می‌سازد) و با سقف تولید چالش
	 * به ازای هر IP محدود شده است.
	 */
	public static function ajax_render() {
		$prefix = ( isset( $_POST['prefix'] ) && 'ff' === $_POST['prefix'] ) ? 'ff' : '';
		$ch     = self::new_challenge();
		if ( is_wp_error( $ch ) ) {
			wp_send_json_error( [ 'error' => $ch->get_error_code(), 'msg' => $ch->get_error_message() ] );
		}
		wp_send_json_success(
			[
				'html'  => self::build_html( $ch, [ 'prefix' => $prefix ] ),
				'nonce' => wp_create_nonce( 'wpmc_frontend' ),
			]
		);
	}
}

<?php
/**
 * حذف تنظیمات هنگام حذف افزونه.
 *
 * transient‌های چالش (عمر ۵ دقیقه) و شمارنده‌های IP (عمر چند دقیقه)
 * خودبه‌خود منقضی می‌شوند.
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wpmc_settings' );
delete_transient( 'wpmc_events' );

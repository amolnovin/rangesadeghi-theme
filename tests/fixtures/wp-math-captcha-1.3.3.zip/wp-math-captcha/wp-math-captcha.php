<?php
/**
 * Plugin Name:       WP Math Captcha (کپچای ریاضی امن)
 * Plugin URI:        https://example.com/wp-math-captcha
 * Description:       کپچای ریاضی با امنیت بالا برای فرم‌های المنتور، فرم نظرات، فرم ورود و Contact Form 7؛ همراه با هانی‌پات، تشخیص ربات، محدودیت نرخ و مسدودسازی IP.
 * Version:           1.3.3
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Arena
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-math-captcha
 *
 * @package WP_Math_Captcha
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPMC_VERSION' ) ) {
	define( 'WPMC_VERSION', '1.3.3' );
}
if ( ! defined( 'WPMC_FILE' ) ) {
	define( 'WPMC_FILE', __FILE__ );
}
if ( ! defined( 'WPMC_DIR' ) ) {
	define( 'WPMC_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'WPMC_URL' ) ) {
	define( 'WPMC_URL', plugin_dir_url( __FILE__ ) );
}

require_once WPMC_DIR . 'includes/class-wpmc-core.php';
require_once WPMC_DIR . 'includes/class-wpmc-captcha.php';
require_once WPMC_DIR . 'includes/class-wpmc-integrations.php';

// فقط اگر هسته‌ی المنتور (Free) فعال است، فایل المنتور را بارگذاری می‌کنیم.
// کلاس‌های Pro داخل همان فایل به‌صورت شرطی تعریف می‌شوند.
if ( defined( 'ELEMENTOR_VERSION' ) || class_exists( '\Elementor\Plugin' ) ) {
	require_once WPMC_DIR . 'includes/class-wpmc-elementor.php';
}

/**
 * فعال‌سازی افزونه: ذخیره‌ی تنظیمات پیش‌فرض.
 */
function wpmc_activate() {
	if ( false === get_option( WP_MC_Core::OPT, false ) ) {
		add_option( WP_MC_Core::OPT, WP_MC_Core::DEFAULTS );
	}
}

/**
 * غیرفعال‌سازی: transient‌ها خودبه‌خود منقضی می‌شوند؛ نیازی به پاک‌سازی فوری نیست.
 */
function wpmc_deactivate() {
	// intentionally empty.
}

register_activation_hook( __FILE__, 'wpmc_activate' );
register_deactivation_hook( __FILE__, 'wpmc_deactivate' );

/**
 * شروع افزونه.
 */
function wpmc_boot() {
	load_plugin_textdomain( 'wp-math-captcha', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	// صفحه‌های مدیریت همیشه در دسترس باشند (حتی اگر افزونه خاموش باشد).
	WP_MC_Core::init_admin();

	if ( ! WP_MC_Core::get( 'enabled', 1 ) ) {
		return;
	}

	WP_MC_Captcha::init();
	WP_MC_Integrations::init();

	if ( class_exists( 'WP_MC_Elementor' ) ) {
		WP_MC_Elementor::init();
	}
}

add_action( 'plugins_loaded', 'wpmc_boot', 5 );

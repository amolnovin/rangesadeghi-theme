<?php
/**
 * استاب‌های کلاس‌های Elementor/Elementor Pro برای تست بدون نصب افزونه‌ها.
 *
 * @package WP_Math_Captcha
 */

namespace Elementor {
	class Plugin {}
}

namespace ElementorPro {
	class Plugin {}
}

namespace ElementorPro\Modules\Forms\Fields {

	/**
	 * بازتابِ دقیقِ Field_Base خودِ Elementor Pro:
	 * سه متد انتزاعی get_type، get_name و get_default_settings.
	 * هر کلاس فیلدی که همه‌ی آن‌ها را پیاده‌سازی نکرده باشد،
	 * دقیقاً مثل محیطِ واقعی، هنگام تعریف کلاس fatal می‌دهد.
	 */
	abstract class Field_Base {
		protected $type;
		protected $label;
		protected $is_hidden;
		protected $is_required;

		public function __construct( $type, $label, $is_hidden = false, $is_required = false ) {
			$this->type        = $type;
			$this->label       = $label;
			$this->is_hidden   = $is_hidden;
			$this->is_required = $is_required;
		}

		abstract public function get_type(): string;
		abstract public function get_name(): string;
		abstract public function get_default_settings(): array;

		public function get_label() {
			return $this->label;
		}
	}
}

namespace {
	define( 'ELEMENTOR_PRO_VERSION', '3.25.0' );
}

<?php
/**
 * استاب‌های حداقلی وردپرس برای تست منطق افزونه بدون نصب وردپرس.
 *
 * @package WP_Math_Captcha
 */

error_reporting( E_ALL );

define( 'ABSPATH', sys_get_temp_dir() . '/wpmc-test/' );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'WPMC_VERSION', '1.0.0' );

$GLOBALS['__transients'] = [];
$GLOBALS['__options']    = [];

function set_transient( $key, $value, $expiration = 0 ) {
	$GLOBALS['__transients'][ $key ] = $value;
	return true;
}

function get_transient( $key ) {
	return array_key_exists( $key, $GLOBALS['__transients'] ) ? $GLOBALS['__transients'][ $key ] : false;
}

function delete_transient( $key ) {
	unset( $GLOBALS['__transients'][ $key ] );
	return true;
}

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['__options'] ) ? $GLOBALS['__options'][ $key ] : $default;
}

function add_option( $key, $value ) {
	if ( ! array_key_exists( $key, $GLOBALS['__options'] ) ) {
		$GLOBALS['__options'][ $key ] = $value;
		return true;
	}
	return false;
}

function update_option( $key, $value ) {
	$GLOBALS['__options'][ $key ] = $value;
	return true;
}

function delete_option( $key ) {
	unset( $GLOBALS['__options'][ $key ] );
}

function wp_salt( $scheme = 'auth' ) {
	return 'stub-salt-' . $scheme;
}

function wp_unslash( $value ) {
	return is_string( $value ) ? stripslashes( $value ) : $value;
}

function wp_strip_all_tags( $string ) {
	return trim( strip_tags( (string) $string ) );
}

function sanitize_text_field( $str ) {
	return wp_strip_all_tags( (string) $str );
}

function absint( $n ) {
	return abs( (int) $n );
}

function __( $text, $domain = 'default' ) {
	return $text;
}

function esc_html__( $text, $domain = 'default' ) {
	return $text;
}

function esc_attr__( $text, $domain = 'default' ) {
	return $text;
}

function esc_html( $text ) {
	return htmlspecialchars( (string) $text, ENT_QUOTES );
}

function esc_attr( $text ) {
	return htmlspecialchars( (string) $text, ENT_QUOTES );
}

function esc_url( $url ) {
	return (string) $url;
}

class WP_Error {
	private $code;
	private $message;
	private $data;

	public function __construct( $code = '', $message = '', $data = '' ) {
		$this->code    = $code;
		$this->message = $message;
		$this->data    = $data;
	}

	public function get_error_code() {
		return $this->code;
	}

	public function get_error_message() {
		return $this->message;
	}

	public function get_error_data() {
		return $this->data;
	}
}

function is_wp_error( $thing ) {
	return $thing instanceof WP_Error;
}

function wp_create_nonce( $action = -1 ) {
	return 'nonce-' . md5( (string) $action );
}

function check_ajax_referer( $action = -1, $query_arg = false, $stop = true ) {
	return 1;
}

function check_admin_referer( $action = -1, $query_arg = '_wpnonce' ) {
	return 1;
}

function admin_url( $path = '' ) {
	return 'http://example.test/wp-admin/' . $path;
}

function add_shortcode( $tag, $cb ) {
	$GLOBALS['__shortcodes'][ $tag ] = $cb;
}

function do_shortcode( $content ) {
	return preg_replace_callback(
		'/\[([a-z_]+)(?:\s[^\/\]]*)?\]/',
		function ( $m ) {
			$cb = $GLOBALS['__shortcodes'][ $m[1] ] ?? null;
			return $cb ? call_user_func( $cb ) : $m[0];
		},
		(string) $content
	);
}

function wp_enqueue_style( ...$args ) {}
function wp_enqueue_script( ...$args ) {}
function wp_localize_script( ...$args ) {}

/* ---------- سیستم هوک‌های ساده (شبیه‌سازی وردپرس) ---------- */

$GLOBALS['__hooks'] = [];

function add_action( $tag, $cb, $priority = 10, $accepted_args = 1 ) {
	$GLOBALS['__hooks'][ $tag ][] = [ 'cb' => $cb, 'args' => (int) $accepted_args ];
	return true;
}

function add_filter( $tag, $cb, $priority = 10, $accepted_args = 1 ) {
	return add_action( $tag, $cb, $priority, $accepted_args );
}

function do_action( $tag, ...$params ) {
	if ( empty( $GLOBALS['__hooks'][ $tag ] ) ) {
		return;
	}
	foreach ( $GLOBALS['__hooks'][ $tag ] as $h ) {
		call_user_func_array( $h['cb'], array_slice( $params, 0, max( 1, $h['args'] ) ) );
	}
}

function apply_filters( $tag, $value, ...$params ) {
	if ( empty( $GLOBALS['__hooks'][ $tag ] ) ) {
		return $value;
	}
	foreach ( $GLOBALS['__hooks'][ $tag ] as $h ) {
		$extra = array_slice( $params, 0, max( 0, $h['args'] - 1 ) );
		$value = call_user_func_array( $h['cb'], array_merge( [ $value ], $extra ) );
	}
	return $value;
}

/* ---------- استاب‌های صفحات و فرم‌های مدیریت ---------- */

function settings_fields( $group ) {
	echo '<input type="hidden" name="option_page" value="' . esc_attr( $group ) . '">';
}

function checked( $checked, $current = true, $display = true ) {
	$res = (string) $checked === (string) $current ? " checked='checked'" : '';
	if ( $display ) {
		echo $res;
	}
	return $res;
}

function selected( $selected, $current = true, $display = true ) {
	$res = (string) $selected === (string) $current ? " selected='selected'" : '';
	if ( $display ) {
		echo $res;
	}
	return $res;
}

function submit_button( $text = null ) {
	echo '<p class="submit"><input type="submit" class="button button-primary" value="ذخیره"></p>';
}

function wp_nonce_field( $action = -1, $name = '_wpnonce', $referer = true, $display = true ) {
	echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="stub-nonce">';
}

function current_user_can( $cap ) {
	return true;
}

function get_current_screen() {
	return null;
}

function date_i18n( $format, $timestamp = null ) {
	return date( $format, (int) ( $timestamp ?: time() ) );
}

function wp_die( $message = '', $title = '', $args = [] ) {
	throw new WPMC_Die_Exception( (string) $message, $args );
}

class WPMC_Die_Exception extends \Exception {
	public $args;

	public function __construct( $message, $args = [] ) {
		parent::__construct( $message );
		$this->args = $args;
	}
}

function wp_safe_redirect( $location, $status = 302, $x = null ) {
	$GLOBALS['__redirect'] = $location;
	return true;
}

function add_query_arg( $args, $url = '' ) {
	return $url . '?' . http_build_query( (array) $args );
}

function register_activation_hook( $file, $cb ) {}
function register_deactivation_hook( $file, $cb ) {}
function load_plugin_textdomain( $domain, $deprecated = null, $rel = false ) {
	return true;
}
function plugin_dir_path( $file ) {
	return trailingslashit( dirname( $file ) );
}
function plugin_dir_url( $file ) {
	return 'http://example.test/wp-content/plugins/' . basename( dirname( $file ) ) . '/';
}
function plugin_basename( $file ) {
	return basename( dirname( $file ) ) . '/' . basename( $file );
}
function trailingslashit( $string ) {
	return rtrim( (string) $string, '/\\' ) . '/';
}

/*
 * با امضای واقعی وردپرس (۲ پارامتر اجباری)؛ فراخوانی نادرست مثل
 * register_setting([...]) همان ArgumentCountError خطا را می‌دهد.
 */
function register_setting( $option_group, $option_name, $args = [] ) {
	$GLOBALS['__registered_settings'][] = [
		'group' => $option_group,
		'name'  => $option_name,
		'args'  => $args,
	];
}

function get_bloginfo( $show = '' ) {
	return '6.7';
}

/* ---------- استاب‌های postmeta (برای حل نام فرم‌های المنتور) ---------- */

$GLOBALS['__post_meta'] = [];

function get_post_meta( $post_id, $key = '', $single = false ) {
	$meta = isset( $GLOBALS['__post_meta'][ (int) $post_id ] ) ? $GLOBALS['__post_meta'][ (int) $post_id ] : [];
	if ( '' === $key ) {
		return $meta;
	}
	if ( ! array_key_exists( $key, $meta ) ) {
		return $single ? '' : [];
	}
	return $single ? $meta[ $key ] : [ $meta[ $key ] ];
}

function update_post_meta( $post_id, $key, $value ) {
	$GLOBALS['__post_meta'][ (int) $post_id ][ $key ] = $value;
	return true;
}

/**
 * شبیه‌سازی واقعی: wp_send_json_* درخواست را تمام می‌کند (die).
 */
class WPMC_Json_Exception extends \Exception {
	public $success;
	public $data;
	public $status;

	public function __construct( $success, $data, $status = null ) {
		parent::__construct( $success ? 'json success' : 'json error' );
		$this->success = (bool) $success;
		$this->data    = $data;
		$this->status  = $status;
	}
}

function wp_send_json_success( $data = null, $status_code = null ) {
	throw new WPMC_Json_Exception( true, $data, $status_code );
}

function wp_send_json_error( $data = null, $status_code = null ) {
	throw new WPMC_Json_Exception( false, $data, $status_code );
}

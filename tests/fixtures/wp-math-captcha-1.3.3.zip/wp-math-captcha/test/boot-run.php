<?php
/**
 * تست بوت کامل افزونه: بارگذاری فایل اصلی، plugins_loaded، admin_init
 * (همین مسیری که در لاگ سایت کاربر fatal شد)، رندر صفحات مدیریت و
 * جریان‌های نظرات/ورود/AJAX.
 *
 * اجرا: php test/boot-run.php
 *
 * @package WP_Math_Captcha
 */

require __DIR__ . '/stubs.php';

// بارگذاری فایل اصلی افزونه (بدون المنتور → مسیر Elementor-Free)
require dirname( __DIR__ ) . '/wp-math-captcha.php';

$pass = 0;
$fail = 0;

function check( $name, $cond ) {
	global $pass, $fail;
	if ( $cond ) {
		$pass++;
		echo "PASS  $name\n";
	} else {
		$fail++;
		echo "FAIL  $name\n";
	}
}

$_SERVER['REMOTE_ADDR']     = '10.2.2.2';
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (boot-test)';
$GLOBALS['__options']['date_format'] = 'Y-m-d';

/* ---------- ۱) بوت افزونه ---------- */

do_action( 'plugins_loaded' );
check( 'plugin boots (plugins_loaded) without fatal', true );

/* ---------- ۲) admin_init: همون خطا‌ی لاگِ کاربر ---------- */

$GLOBALS['__registered_settings'] = [];
do_action( 'admin_init' );
$regs = $GLOBALS['__registered_settings'];
check(
	'admin_init → register_setting بدون ArgumentCountError',
	1 === count( $regs ) && 'wpmc_group' === $regs[0]['group'] && 'wpmc_settings' === $regs[0]['name']
);

// در سایت بدون Elementor، payload مشابهِ AJAX سایر افزونه‌ها نباید توسط
// دروازه‌ی Elementor لمس شود.
$_POST = [
	'action'      => 'other_plugin_submit',
	'post_id'     => 1,
	'form_id'     => 'other-form',
	'form_fields' => [ 'email' => 'user@example.com' ],
];
$unrelated_ok = true;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$unrelated_ok = false;
}
check( 'بدون Elementor: AJAX سایر افزونه‌ها بدون مداخله عبور می‌کند', $unrelated_ok );

/* ---------- ۳) رندر صفحات مدیریت ---------- */

ob_start();
WP_MC_Core::render_settings();
$out = ob_get_clean();
check( 'صفحه‌ی تنظیمات رندر می‌شود', false !== strpos( $out, 'wpmc_settings[enabled]' ) );
check( 'پیش‌نمایش کپچا در تنظیمات', false !== strpos( $out, 'wpmc-captcha' ) );

ob_start();
WP_MC_Core::render_logs();
$out2 = ob_get_clean();
check( 'صفحه‌ی رویدادها رندر می‌شود', false !== strpos( $out2, 'wpmc' ) );

/* ---------- ۴) جریان کامل فرم نظر ---------- */

$html = do_shortcode( '[math_captcha]' );
preg_match( '/name="wpmc_token" value="([^"]+)"/', $html, $m );
check( 'shortcode فیلد توکن می‌دهد', isset( $m[1] ) );
$token = $m[1];
$id    = explode( '.', $token )[0];
$t     = get_transient( 'wpmc_ch_' . $id );
$t['created'] = time() - 10;
set_transient( 'wpmc_ch_' . $id, $t, 300 );
$ans   = (string) $t['ans'];

$_POST = [
	'wpmc_answer'  => $ans,
	'wpmc_token'   => $token,
	'wpmc_website' => '',
];
$r = apply_filters( 'preprocess_comment', [ 'comment_post_ID' => 1 ] );
check( 'نظر معتبر از preprocess_comment عبور می‌کند', is_array( $r ) && 1 === $r['comment_post_ID'] );

// نمایش استاندارد: بعد از متن نظر و قبل از دکمه‌ی ارسال.
$comment_submit = apply_filters( 'comment_form_submit_field', '<button type="submit">ارسال</button>', [] );
check( 'فرم نظر کپچا را قبل از دکمه‌ی ارسال می‌گیرد', false !== strpos( $comment_submit, 'comment-form-wpmc' ) && false !== strpos( $comment_submit, 'wpmc-captcha' ) );

// حذف کامل فیلدهای کپچا از POST نباید راه عبور باشد.
$_POST = [ 'comment' => 'ربات بدون کپچا', 'comment_post_ID' => 1 ];
$comment_blocked = false;
try {
	apply_filters( 'preprocess_comment', [ 'comment_post_ID' => 1 ] );
} catch ( WPMC_Die_Exception $e ) {
	$comment_blocked = true;
}
check( 'نظر بدون فیلدهای کپچا → 403 (fail-closed)', $comment_blocked );

// ووکامرس review از نظر وردپرس همان comment است و باید همان مسیر را طی کند.
$html_review = do_shortcode( '[math_captcha]' );
preg_match( '/name="wpmc_token" value="([^"]+)"/', $html_review, $m );
$token_review = $m[1];
$id_review    = explode( '.', $token_review )[0];
$t_review     = get_transient( 'wpmc_ch_' . $id_review );
$t_review['created'] = time() - 10;
set_transient( 'wpmc_ch_' . $id_review, $t_review, 300 );
$_POST = [
	'comment'      => 'review معتبر',
	'comment_post_ID' => 99,
	'comment_type' => 'review',
	'wpmc_answer'  => (string) $t_review['ans'],
	'wpmc_token'   => $token_review,
	'wpmc_website' => '',
];
$r_review = apply_filters( 'preprocess_comment', [ 'comment_post_ID' => 99, 'comment_type' => 'review' ] );
check( 'Review محصول با کپچای معتبر از همان مسیر comment عبور می‌کند', is_array( $r_review ) && 'review' === $r_review['comment_type'] );

// هانی‌پات → wp_die 403
$html   = do_shortcode( '[math_captcha]' );
preg_match( '/name="wpmc_token" value="([^"]+)"/', $html, $m );
$token2 = $m[1];
$id2    = explode( '.', $token2 )[0];
$t2     = get_transient( 'wpmc_ch_' . $id2 );
$t2['created'] = time() - 10;
set_transient( 'wpmc_ch_' . $id2, $t2, 300 );
$_POST = [
	'wpmc_answer'  => (string) $t2['ans'],
	'wpmc_token'   => $token2,
	'wpmc_website' => 'http://spam.example',
];
$threw  = false;
$status = null;
try {
	apply_filters( 'preprocess_comment', [ 'comment_post_ID' => 1 ] );
} catch ( WPMC_Die_Exception $e ) {
	$threw  = true;
	$status = isset( $e->args['response'] ) ? (int) $e->args['response'] : null;
}
check( 'نظر با هانی‌پات پرشده با 403 مردود می‌شود', $threw && 403 === $status );

/* ---------- ۵) جریان کامل فرم ورود ---------- */

$form = apply_filters( 'login_form_login', '<form></form>' );
check( 'فرم ورود کپچا می‌گیرد', false !== strpos( $form, 'wpmc-captcha' ) );

preg_match( '/name="wpmc_token" value="([^"]+)"/', $form, $m );
$token3 = $m[1];
$id3    = explode( '.', $token3 )[0];
$t3     = get_transient( 'wpmc_ch_' . $id3 );
$t3['created'] = time() - 10;
set_transient( 'wpmc_ch_' . $id3, $t3, 300 );

$_POST = [
	'wpmc_answer'  => (string) $t3['ans'],
	'wpmc_token'   => $token3,
	'wpmc_website' => '',
];
$sec = apply_filters( 'authenticate', 'user-object', 'admin', 'pw' );
check( 'ورود معتبر از authenticate عبور می‌کند', 'user-object' === $sec );

// ورود با جواب نادرست → WP_Error
$html   = do_shortcode( '[math_captcha]' );
preg_match( '/name="wpmc_token" value="([^"]+)"/', $html, $m );
$token4 = $m[1];
$id4    = explode( '.', $token4 )[0];
$t4     = get_transient( 'wpmc_ch_' . $id4 );
$t4['created'] = time() - 10;
set_transient( 'wpmc_ch_' . $id4, $t4, 300 );
$_POST = [
	'wpmc_answer'  => (string) ( (int) $t4['ans'] + 42 ),
	'wpmc_token'   => $token4,
	'wpmc_website' => '',
];
$r = apply_filters( 'authenticate', 'user-object', 'admin', 'pw' );
check( 'ورود با کپچای نادرست → WP_Error', is_wp_error( $r ) && 'wpmc_captcha_failed' === $r->get_error_code() );

/* ---------- ۶) AJAX ---------- */

$_POST = [ 'prefix' => 'ff' ];
try {
	WP_MC_Captcha::ajax_render();
	check( 'ajax_render باید پاسخ JSON بدهد', false );
} catch ( WPMC_Json_Exception $e ) {
	check( 'ajax_render JSON موفق + فیلدهای المنتور', $e->success && false !== strpos( (string) $e->data['html'], 'form_fields[wpmc_answer]' ) );
}

$_POST = [ 'prefix' => 'ff', 'nonce' => 'x' ];
try {
	WP_MC_Captcha::ajax_refresh();
	check( 'ajax_refresh باید پاسخ JSON بدهد', false );
} catch ( WPMC_Json_Exception $e ) {
	check( 'ajax_refresh JSON موفق', $e->success && false !== strpos( (string) $e->data['html'], 'wpmc-captcha' ) );
}

/* ---------- ۷) sanitize: محدودسازی ورودی‌ها ---------- */

$s = WP_MC_Core::sanitize(
	[
		'difficulty'     => 'nope',
		'max_num'        => '500', // در حالت غیر-سفارشی باید بی‌اثر بماند
		'min_time'       => '500',
		'fail_threshold' => '0',
		'lock_minutes'   => '99999',
		'gen_limit'      => '0',
		'elementor_scope' => 'x',
	]
);
check( 'sanitize: max_num در حالت غیر-سفارشی بی‌اثر می‌ماند', 20 === $s['max_num'] );
check( 'sanitize: min_time ≤ 60', 60 === $s['min_time'] );
check( 'sanitize: fail_threshold ≥ 1', 1 === $s['fail_threshold'] );
check( 'sanitize: lock_minutes ≤ 1440', 1440 === $s['lock_minutes'] );
check( 'sanitize: gen_limit ≥ 1', 1 === $s['gen_limit'] );
check( 'sanitize: difficulty نامعتبر → medium', 'medium' === $s['difficulty'] );
check( 'sanitize: scope نامعتبر → all', 'all' === $s['elementor_scope'] );

$s2 = WP_MC_Core::sanitize(
	[
		'difficulty' => 'custom',
		'ops'        => [ 'mul' => '1' ],
		'max_num'    => '500',
	]
);
check( 'sanitize: حالت سفارشی op ضرب + max_num ≤ 99', [ 'x' ] === $s2['ops'] && 99 === $s2['max_num'] );

$s3 = WP_MC_Core::sanitize( [ 'min_time' => '-5' ] );
check( 'sanitize: min_time منفی → مقدار مطلق (هرگز منفی نیست)', 5 === $s3['min_time'] );

echo "\n----------------------------------------\n";
echo "PASSED: $pass   FAILED: $fail\n";
exit( $fail > 0 ? 1 : 0 );

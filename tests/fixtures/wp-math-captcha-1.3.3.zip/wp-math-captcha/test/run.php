<?php
/**
 * تست‌های یگان منطق امنیتی WPMC (بدون وردپرس).
 * اجرا: php test/run.php
 *
 * @package WP_Math_Captcha
 */

require __DIR__ . '/stubs.php';
require dirname( __DIR__ ) . '/includes/class-wpmc-core.php';
require dirname( __DIR__ ) . '/includes/class-wpmc-captcha.php';

$_SERVER['REMOTE_ADDR']     = '10.0.0.1';
$_SERVER['HTTP_USER_AGENT'] = 'WPMC-TestSuite/1.0 (legit-browser)';

$pass = 0;
$fail = 0;

function check( $name, $cond ) {
	global $pass, $fail;
	if ( $cond ) {
		$pass++;
		echo "PASS  $name\n";
	} else {
		$fail++;
		echo "FAIL  $name\n";
	}
}

/**
 * زمانِ ساخت چالش را به گذشته برمی‌گردانیم تا min_time عبور شود.
 */
function backdate( $token, $sec = 10 ) {
	$id  = explode( '.', $token )[0];
	$t   = get_transient( 'wpmc_ch_' . $id );
	$t['created'] = time() - $sec;
	set_transient( 'wpmc_ch_' . $id, $t, 300 );
}

/**
 * پاک‌سازی وضعیت خطا/قرنطینه‌ی IP (برای جداسازی گروه‌های تست).
 */
function reset_ip( $ip = '10.0.0.1' ) {
	delete_transient( 'wpmc_fail_' . md5( $ip ) );
	delete_transient( 'wpmc_lock_' . md5( $ip ) );
}

/* ---------- ۱) تولید چالش ---------- */

$ch = WP_MC_Captcha::new_challenge();
check( 'challenge is array with token', is_array( $ch ) && isset( $ch['token'], $ch['a'], $ch['b'], $ch['op'], $ch['ans'] ) );

$expected = 'x' === $ch['op'] ? $ch['a'] * $ch['b'] : ( '-' === $ch['op'] ? $ch['a'] - $ch['b'] : $ch['a'] + $ch['b'] );
check( 'challenge math is correct', $expected === (int) $ch['ans'] );
check( 'subtraction never negative', '-' !== $ch['op'] || (int) $ch['ans'] >= 0 );

/* ---------- ۲) ارسال خیلی سریع (حتی با جواب درست) ---------- */

$r = WP_MC_Captcha::verify( (string) $ch['ans'], $ch['token'], '', 'test' );
check( 'too-fast rejected even with right answer', is_wp_error( $r ) && 'too_fast' === $r->get_error_code() );

/* ---------- ۳) جواب درست بعد از عبور min_time ---------- */

backdate( $ch['token'] );
$id  = explode( '.', $ch['token'] )[0];
$r   = WP_MC_Captcha::verify( (string) $ch['ans'], $ch['token'], '', 'test' );
check( 'correct answer passes', true === $r );
check( 'challenge consumed (single-use)', false === get_transient( 'wpmc_ch_' . $id ) );

/* ---------- ۴) توکن جعلی ---------- */

$r = WP_MC_Captcha::verify( '5', 'deadbeefcafe0123.notasignature', '', 'test' );
check( 'forged token rejected', is_wp_error( $r ) && 'bad_token' === $r->get_error_code() );

/* ---------- ۵) Replay: توکنِ استفاده‌شده‌ی قبلی ---------- */

$r = WP_MC_Captcha::verify( (string) $ch['ans'], $ch['token'], '', 'test' );
check( 'replay attack rejected (expired)', is_wp_error( $r ) && 'expired' === $r->get_error_code() );

/* ---------- ۶) هانی‌پات ---------- */

$ch2 = WP_MC_Captcha::new_challenge();
$r   = WP_MC_Captcha::verify( (string) $ch2['ans'], $ch2['token'], 'http://spam-site.ru', 'test' );
check( 'honeypot filled -> rejected', is_wp_error( $r ) && 'honeypot' === $r->get_error_code() );

/* ---------- ۷) جواب نادرست + تلاش‌های بعدی + ارقام فارسی ---------- */

backdate( $ch2['token'] );
$wrong = (string) ( (int) $ch2['ans'] + 1 );
$r     = WP_MC_Captcha::verify( $wrong, $ch2['token'], '', 'test' );
check( 'wrong answer rejected', is_wp_error( $r ) && 'wrong' === $r->get_error_code() );

$id2 = explode( '.', $ch2['token'] )[0];
$t2  = get_transient( 'wpmc_ch_' . $id2 );
check( 'attempts counter incremented', is_array( $t2 ) && 1 === (int) $t2['attempts'] );

$persian = WP_MC_Captcha::to_persian( (string) $ch2['ans'] );
$r       = WP_MC_Captcha::verify( $persian, $ch2['token'], '', 'test' );
check( 'persian digits accepted as answer', true === $r );

/* ---------- ۸) سقف تلاش: بعد از ۳ اشتباه، چالش باطل ---------- */

$ch3  = WP_MC_Captcha::new_challenge();
backdate( $ch3['token'] );
$id3  = explode( '.', $ch3['token'] )[0];
$last = null;
for ( $i = 0; $i < 3; $i++ ) {
	$last = WP_MC_Captcha::verify( (string) ( (int) $ch3['ans'] + 7 ), $ch3['token'], '', 'test' );
}
check( '3rd wrong answer -> wrong_final', is_wp_error( $last ) && 'wrong_final' === $last->get_error_code() );
check( 'challenge invalidated after max attempts', false === get_transient( 'wpmc_ch_' . $id3 ) );

/* ---------- ۹) قرنطینه IP بعد از آستانه ---------- */

reset_ip(); // جداسازی از خطاهای گروه‌های قبل
// شمارنده‌ی خطا را به آستانه - 1 می‌رسانیم تا یک خطای دیگر کلید بزند.
set_transient( 'wpmc_fail_' . md5( '10.0.0.1' ), 7, 900 );
$ch4  = WP_MC_Captcha::new_challenge();
backdate( $ch4['token'] );
$r    = WP_MC_Captcha::verify( (string) ( (int) $ch4['ans'] + 100 ), $ch4['token'], '', 'test' );
check( 'IP locked out after threshold', (bool) get_transient( 'wpmc_lock_' . md5( '10.0.0.1' ) ) );

$r = WP_MC_Captcha::verify( '1', 'anything.here', '', 'test' );
check( 'locked IP rejected immediately', is_wp_error( $r ) && 'ip_locked' === $r->get_error_code() );

/* ---------- ۱۰) ربات شناخته‌شده ---------- */

delete_transient( 'wpmc_lock_' . md5( '10.0.0.1' ) );
$_SERVER['HTTP_USER_AGENT'] = 'python-requests/2.31.0';
$ch5                        = WP_MC_Captcha::new_challenge();
backdate( $ch5['token'] );
$r                          = WP_MC_Captcha::verify( (string) $ch5['ans'], $ch5['token'], '', 'test' );
check( 'bot user-agent rejected', is_wp_error( $r ) && 'bot_ua' === $r->get_error_code() );

/* ---------- ۱۱) جواب خالی ---------- */

reset_ip();
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (legit)';
$ch6                        = WP_MC_Captcha::new_challenge();
backdate( $ch6['token'] );
$r                          = WP_MC_Captcha::verify( '', $ch6['token'], '', 'test' );
check( 'empty answer -> missing (not counted as fail)', is_wp_error( $r ) && 'missing' === $r->get_error_code() );

/* ---------- ۱۲) خروجی HTML ---------- */

$html = WP_MC_Captcha::output( [ 'prefix' => 'ff' ] );
check( 'html has input with form_fields prefix', false !== strpos( $html, 'name="form_fields[wpmc_answer]"' ) );
check( 'html has hidden token', false !== strpos( $html, 'name="form_fields[wpmc_token]"' ) );
check( 'html has honeypot', false !== strpos( $html, 'name="form_fields[wpmc_website]"' ) );
check( 'html has refresh button', false !== strpos( $html, 'wpmc-refresh' ) );
check( 'html has nonce attribute', false !== strpos( $html, 'data-nonce="nonce-' ) );

$html_bare = WP_MC_Captcha::output();
check( 'bare output uses unprefixed names', false !== strpos( $html_bare, 'name="wpmc_answer"' ) );

/* ---------- ۱۳) سقف تولید چالش ---------- */

$opts                       = get_option( 'wpmc_settings', [] );
$opts['gen_limit']          = 1;
$GLOBALS['__options']['wpmc_settings'] = $opts;
set_transient( 'wpmc_gen_' . md5( '10.0.0.1' ), 1, 600 );
$r = WP_MC_Captcha::new_challenge();
check( 'generation limit enforced', is_wp_error( $r ) && 'gen_limit' === $r->get_error_code() );
unset( $GLOBALS['__options']['wpmc_settings'] );

/* ---------- ۱۳.۵) رگرسیون: register_setting با امضای واقعی وردپرس ---------- */

$GLOBALS['__registered_settings'] = [];
WP_MC_Core::register_settings(); // نباید ArgumentCountError بدهد
$regs = $GLOBALS['__registered_settings'];
check(
	'register_settings uses classic 3-arg form (no ArgumentCountError)',
	1 === count( $regs )
		&& 'wpmc_group' === $regs[0]['group']
		&& 'wpmc_settings' === $regs[0]['name']
		&& is_callable( $regs[0]['args']['sanitize_callback'] )
);

/* ---------- ۱۴) normalize ---------- */

check( 'normalize arabic digits', '123' === WP_MC_Captcha::normalize( '١٢٣' ) );
check( 'normalize persian digits', '45' === WP_MC_Captcha::normalize( '۴۵' ) );
check( 'normalize strips noise', '7' === WP_MC_Captcha::normalize( '  ۷ ؟ ' ) );
check( 'normalize minus sign', '5' === WP_MC_Captcha::normalize( '۵−' ) || '5' === WP_MC_Captcha::normalize( '5' ) );

echo "\n----------------------------------------\n";
echo "PASSED: $pass   FAILED: $fail\n";
exit( $fail > 0 ? 1 : 0 );

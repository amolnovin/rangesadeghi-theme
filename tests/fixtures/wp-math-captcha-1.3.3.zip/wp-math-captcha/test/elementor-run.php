<?php
/**
 * تست لایه‌ی Elementor: دروازه‌ی اصلی (AJAX gate) + مسیر پشتیبان.
 * اجرا: php test/elementor-run.php
 *
 * @package WP_Math_Captcha
 */

require __DIR__ . '/stubs.php';
require __DIR__ . '/elementor-stubs.php'; // استاب‌های Elementor/Elementor Pro
require dirname( __DIR__ ) . '/includes/class-wpmc-core.php';
require dirname( __DIR__ ) . '/includes/class-wpmc-captcha.php';
require dirname( __DIR__ ) . '/includes/class-wpmc-elementor.php';

WP_MC_Captcha::init();
WP_MC_Elementor::init();

$_SERVER['REMOTE_ADDR']     = '10.1.1.1';
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (integration-test)';

$pass = 0;
$fail = 0;
function check( $name, $cond ) {
	global $pass, $fail;
	if ( $cond ) {
		$pass++;
		echo "PASS  $name\n";
	} else {
		$fail++;
		echo "FAIL  $name\n";
	}
}

function backdate( $token, $sec = 10 ) {
	$id  = explode( '.', $token )[0];
	$t   = get_transient( 'wpmc_ch_' . $id );
	$t['created'] = time() - $sec;
	set_transient( 'wpmc_ch_' . $id, $t, 300 );
}

function reset_ip( $ip = '10.1.1.1' ) {
	delete_transient( 'wpmc_fail_' . md5( $ip ) );
	delete_transient( 'wpmc_lock_' . md5( $ip ) );
}

function set_scope( $scope, $ids = '' ) {
	$GLOBALS['__options']['wpmc_settings'] = [
		'elementor_scope'    => $scope,
		'elementor_form_ids' => $ids,
	];
}

function make_challenges( $n = 1 ) {
	$out = [];
	for ( $i = 0; $i < $n; $i++ ) {
		$ch = WP_MC_Captcha::new_challenge();
		backdate( $ch['token'] );
		$out[] = $ch;
	}
	return $out;
}

function gate_expect( $post, $should_block ) {
	// اجرای واقعیِ درخواست AJAX فرم المنتور:
	do_action( 'wp_ajax_nopriv_elementor_pro/forms_handle_form' );
}

/* آماده‌سازی اولیه */
reset_ip();
WP_MC_Elementor::reset_state();
set_scope( 'selected', 'form-alpha, My Form Name' );

/* ---------- ۱) دروازه: فرم در لیست + جواب نادرست → بلوک ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [
		'your-name'    => 'bot',
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 55 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$blocked = false;
try {
	gate_expect( $_POST, true );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ( ! $e->success && 400 === $e->status && ! empty( $e->data['message'] ) );
}
check( 'دروازه: فرمِ لیست‌شده با جواب نادرست → 400', $blocked );

/* ---------- ۲) دروازه: فرم در لیست + جواب درست → عبور ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [
		'wpmc_answer'  => (string) $ch['ans'],
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$passed = true;
try {
	gate_expect( $_POST, false );
} catch ( WPMC_Json_Exception $e ) {
	$passed = false;
}
check( 'دروازه: فرمِ لیست‌شده با جواب درست → عبور (اجرای المنتور ادامه می‌یابد)', $passed );
$ch_id = explode( ".", $ch["token"] )[0];
check( 'دروازه: چالش پس از موفقیت مصرف شده (تک‌بار مصرفی)', false === get_transient( 'wpmc_ch_' . $ch_id ) );

/* ---------- ۳) دروازه: فرم در لیست اما فیلدهای کپچا حذف‌شده (ربات) → بلوک ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [ 'your-name' => 'stripped bot' ],
];
$blocked = false;
try {
	gate_expect( $_POST, true );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'دروازه: حذف فیلدهای کپچا در فرمِ لیست‌شده → بلوک (fail-closed)', $blocked );

/* ---------- ۴) دروازه: فرم خارج از لیست و بدون کپچا → دست نمی‌خورد ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'other-form-999',
	'form_name'   => 'Newsletter',
	'form_fields' => [ 'email' => 'user@example.com' ],
];
$passed = true;
try {
	gate_expect( $_POST, false );
} catch ( WPMC_Json_Exception $e ) {
	$passed = false;
}
check( 'دروازه: فرمِ خارج از محدوده بدون کپچا → بدون مداخله', $passed );

/* ---------- ۵) دروازه: فرم خارج از لیست اما دارای فیلدهای کپچا → اعتبارسنجی ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-not-listed',
	'form_name'   => 'Placed Manually',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 11 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$blocked = false;
try {
	gate_expect( $_POST, true );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'دروازه: فرمِ بدون لیست ولی دارای کپچا (فیلد دستی) → اعتبارسنجی و بلوک', $blocked );

/* ---------- ۶) دروازه: تطبیق بر اساس نام فرم ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'unknown-element-id',
	'form_name'   => 'My Form Name',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 77 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$blocked = false;
try {
	gate_expect( $_POST, true );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'دروازه: تطبیق فرم از روی نام فرم (Form Name)', $blocked );

/* ---------- ۷) دروازه: حالت «همه فرم‌ها» ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
set_scope( 'all' );
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'any-form',
	'form_name'   => 'Whatever',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 3 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$blocked = false;
try {
	gate_expect( $_POST, true );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'دروازه: حالت «همه فرم‌ها» → تمام فرم‌ها اعتبارسنجی می‌شوند', $blocked );
set_scope( 'selected', 'form-alpha, My Form Name' );

/* ---------- ۸) مسیر پشتیبان: دروازه اجرا نشد → هوک‌های فرم بلوک می‌کنند ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$data = [
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 21 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
do_action( 'elementor_pro/forms/actions', $data );
$resp = apply_filters( 'elementor_pro/forms/submission', [ 'code' => 200, 'message' => 'ok' ], $data );
check( 'پشتیبان: هوک‌های فرم → پاسخ 400 + پیام', 400 === $resp['code'] && '' !== $resp['message'] );

/* ---------- ۹) بدون اعتبارسنجی کاذب: دروازه موفق شد، هوک تکرار نمی‌کند ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [
		'wpmc_answer'  => (string) $ch['ans'],
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
try {
	gate_expect( $_POST, false );
} catch ( WPMC_Json_Exception $e ) {
	// نباید رخ بدهد.
}
// حالا فرض می‌کنیم نسخه‌ی المنتور هوک actions را هم اجرا می‌کند (با چالش مصرف‌شده):
$data = [
	'form_id'     => 'form-alpha',
	'form_name'   => 'Contact',
	'form_fields' => [
		'wpmc_answer'  => (string) $ch['ans'],
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
do_action( 'elementor_pro/forms/actions', $data );
$resp = apply_filters( 'elementor_pro/forms/submission', [ 'code' => 200, 'message' => 'ok' ], $data );
check( 'بدون اعتبارسنجی دوتایی: هوک‌های فرم پس از موفقیت دروازه مداخله نمی‌کنند', 200 === $resp['code'] && 'ok' === $resp['message'] );

/* ---------- ۱۰) ثبت فیلد در fields manager ---------- */

WP_MC_Elementor::reset_state();
$manager = new class {
	public $registered = [];
	public function register( $field ) {
		$this->registered[] = $field;
	}
};
do_action( 'elementor_pro/forms/fields/register', $manager ); // هوک رسمیِ مستندات المنتور
check( 'فیلد اختصاصی با هوک رسمی (fields/register) ثبت شد', 1 === count( $manager->registered ) && $manager->registered[0] instanceof WP_MC_Elementor_Captcha_Field );
do_action( 'elementor_pro/forms/register_fields', $manager );
do_action( 'elementor_pro/forms/fields', $manager );
check( 'ثبت تکراری از مسیرهای دیگر نمی‌شود', 1 === count( $manager->registered ) );

// بازگشت از خطای فیتال واقعی سایت کاربر: کلاس فیلد باید همه‌ی متدهای
// انتزاعی Field_Base (get_type / get_name / get_default_settings) را پیاده کرده باشد.
$ref = new \ReflectionClass( $manager->registered[0] );
check( 'کلاس فیلد instantiable است (بدون متد انتزاعی پیاده‌نشده — رگرسیون fatal)', $ref->isInstantiable() );
check( 'get_type() کلید ماشینی فیلد را برمی‌گرداند', 'wpmc_math_captcha' === $manager->registered[0]->get_type() );
check( 'get_name() نام نمایشی غیرخالی برمی‌گرداند', is_string( $manager->registered[0]->get_name() ) && '' !== trim( (string) $manager->registered[0]->get_name() ) );
// استاب، get_default_settings را انتزاعی تعریف کرده (مثل نسخه‌های جدید المنتور):
// فراخوانی نباید fatal بدهد و باید label برگرداند.
$defaults = $manager->registered[0]->get_default_settings();
check( 'get_default_settings با parent انتزاعی بدون fatal اجرا می‌شود', is_array( $defaults ) && isset( $defaults['label'] ) );

/* ---------- ۱۱) خروجی فیلد با پیشوند فرم‌های المنتور ---------- */

ob_start();
$manager->registered[0]->render_field( [], [], [] );
$out = ob_get_clean();
check( 'فیلد ورودی (render_field) با پیشوند form_fields می‌دهد', false !== strpos( $out, 'name="form_fields[wpmc_answer]"' ) );
check( 'فیلد توکن مخفی (render_field) با پیشوند form_fields می‌دهد', false !== strpos( $out, 'name="form_fields[wpmc_token]"' ) );

// API فعلیِ المنتور: render( $item, $item_index, $form )
ob_start();
$manager->registered[0]->render(
	[ 'id' => 'wpmc_math_captcha_x1y2', 'type' => 'wpmc_math_captcha' ],
	2,
	new stdClass()
);
$out = ob_get_clean();
check( 'فیلد ورودی (render فعلی) با پیشوند form_fields می‌دهد', false !== strpos( $out, 'name="form_fields[wpmc_answer]"' ) );
check( 'فیلد توکن مخفی (render فعلی) با پیشوند form_fields می‌دهد', false !== strpos( $out, 'name="form_fields[wpmc_token]"' ) );

/* ---------- ۱۲) توری (admin_init): بلوک حتی با نام اکشنِ عوض‌شده ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form_futur3', // فرض: المنتور در آینده نام اکشن را عوض کرده
	'form_id'     => 'form-alpha',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 5 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$blocked = false;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success && 400 === $e->status;
}
check( 'توری admin_init: با نام اکشنِ متفاوت هم بلوک می‌کند', $blocked );

/* ---------- ۱۳) توری: شناسایی با «شکلِ» payload بدون نام اکشنِ شناخته‌شده ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$_POST = [
	'action'      => 'totally_unrelated_action',
	'post_id'     => 42,
	'form_id'     => 'form-alpha',
	'form_fields' => [ 'name' => 'bot' ], // بدون فیلدهای کپچا
];
$blocked = false;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'توری admin_init: post_id + form_id + form_fields (شکلِ ارسال فرم) → اعتبارسنجی fail-closed', $blocked );

/* ---------- ۱۴) فرمِ مشابهِ افزونه‌ی دیگر بدون post_id → بدون مداخله ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$_POST = [
	'action'      => 'totally_unrelated_action',
	'form_id'     => 'other-plugin-form',
	'form_fields' => [ 'email' => 'user@example.com' ],
];
$ok = true;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$ok = false;
}
check( 'توری: payload مشابهِ افزونه‌ی دیگر بدون post_id → بدون تداخل', $ok );

/* ---------- ۱۵) توری + هوک اختصاصی: یک درخواست، یک‌بار اعتبارسنجی ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_fields' => [
		'wpmc_answer'  => (string) $ch['ans'],
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$ok = true;
try {
	do_action( 'admin_init' ); // لایه‌ی توری: معتبر است → چالش مصرف شد
} catch ( WPMC_Json_Exception $e ) {
	$ok = false;
}
try {
	do_action( 'wp_ajax_nopriv_elementor_pro/forms_handle_form' ); // لایه‌ی اختصاصی: نباید دوباره بخواند
} catch ( WPMC_Json_Exception $e ) {
	$ok = false;
}
check( 'بدون اعتبارسنجی دوتایی: توری و هوک اختصاصی یک درخواست را یک‌بار می‌بینند', $ok );

/* ---------- ۱۵) توری: درخواست‌های AJAX غیرفرمی دست‌نخورده ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$_POST = [ 'action' => 'wpmc_render', 'prefix' => 'ff' ];
$ok = true;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$ok = false;
}
check( 'توری admin_init: AJAX‌های غیرفرمی بدون مداخله عبور می‌کنند', $ok );

/* ---------- ۱۶) تطبیق با «نام فرم» از داده‌ی صفحه (_elementor_data) ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
set_scope( 'selected', 'contact-us' ); // کاربر نام فرم را وارد کرده، نه شناسه‌ی المان
$GLOBALS['__post_meta'][ 42 ] = [
	'_elementor_data' => json_encode(
		[
			[
				'id'       => 'col-1',
				'elements' => [
					[
						'id'       => 'abcd1234',
						'settings' => [ 'form_name' => 'contact-us' ],
					],
				],
			],
		]
	) ,
];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'abcd1234',
	'post_id'     => 42,
	'form_fields' => [ 'email' => 'user@example.com' ], // بدون کپچا (ربات) → باید بلوک شود
];
$blocked = false;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$blocked = ! $e->success;
}
check( 'نام فرم: از _elementor_data حل می‌شود و فرم محافظت می‌شود', $blocked );

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'abcd1234',
	'post_id'     => 42,
	'form_fields' => [
		'wpmc_answer'  => (string) $ch['ans'],
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$ok = true;
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	$ok = false;
}
check( 'نام فرم: با کپچای معتبر → عبور', $ok );
set_scope( 'selected', 'form-alpha, My Form Name' );

/* ---------- ۱۷) لایه‌ی پشتیبان: elementor_pro/forms/validation با add_error ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$ch   = make_challenges()[0];
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'form-alpha',
	'form_fields' => [
		'wpmc_answer'  => (string) ( (int) $ch['ans'] + 99 ),
		'wpmc_token'   => $ch['token'],
		'wpmc_website' => '',
	],
];
$fake_handler = new class {
	public $errors = [];
	public function add_error( $field, $message ) {
		$this->errors[ $field ] = $message;
	}
};
// فرض: دروازه اجرا نشده (مسیر ارسال متفاوت) و هوک validation المنتور فایر شده:
do_action( 'elementor_pro/forms/validation', null, $fake_handler );
check(
	'لایه‌ی پشتیبان: elementor_pro/forms/validation → add_error (المنتور خطا را نشان می‌دهد)',
	isset( $fake_handler->errors['wpmc_captcha'] ) && '' !== $fake_handler->errors['wpmc_captcha']
);

/* ---------- ۱۸) عیب‌یابی: حتی فرمِ عبورکرده (خارج از محدوده) رکورد می‌گیرد ---------- */

reset_ip();
WP_MC_Elementor::reset_state();
$GLOBALS['__options']['wpmc_settings']['debug'] = 1;
$_POST = [
	'action'      => 'elementor_pro/forms_handle_form',
	'form_id'     => 'some-random-form',
	'form_fields' => [ 'email' => 'x@example.com' ],
];
try {
	do_action( 'admin_init' );
} catch ( WPMC_Json_Exception $e ) {
	// نباید رخ بدهد (خارج از محدوده).
}
$events = WP_MC_Core::events();
$found  = false;
foreach ( $events as $ev ) {
	if ( 'debug' === $ev['reason'] && false !== strpos( $ev['ctx'], 'gate' ) && false !== strpos( $ev['ctx'], 'some-random-form' ) ) {
		$found = true;
	}
}
check( 'عیب‌یابی: برای فرمِ عبورکرده هم رکورد debug (با نسخه و لیست) نوشته می‌شود', $found );
unset( $GLOBALS['__options']['wpmc_settings']['debug'] );

echo "\n----------------------------------------\n";
echo "PASSED: $pass   FAILED: $fail\n";
exit( $fail > 0 ? 1 : 0 );

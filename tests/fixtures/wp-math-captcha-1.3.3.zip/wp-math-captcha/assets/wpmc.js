/**
 * WP Math Captcha — اسکریپت فرانت (v1.3.3)
 *
 * ۱) نوسازی چالش (دکمه‌ی ↻)
 * ۲) تزریق خودکار کپچا به فرم‌های المنتور:
 *    - شناسایی فرم با فیلد پنهان input[name="form_id"] که خودِ المنتور در
 *      داخل form می‌گذارد (مستقل از کلاس‌ها و ساختار wrapperهای المنتور).
 *    - درج همیشه «داخل» <form> و «بالای» دکمه‌ی ارسال: از دکمه به سمت بالا
 *      تا اولین عنصری که بچه‌ی مستقیم form باشد حرکت می‌کنیم (سازگار با
 *      wrapperهای تودرتو: button-wrapper داخل actions-wrapper) و کپچا را
 *      قبل از همان عنصر درج می‌کنیم.
 * ۳) اعتبارسنجی کلاینتی هنگام submit: اگر جواب خالی باشد، فرم همان‌جا
 *    توقف می‌کند و پیام می‌دهد (بدون نیاز به رفت‌وبرگشت با سرور).
 *    محافظت واقعی از سمت سرور است؛ این بخش فقط تجربه‌ی کاربر را بهتر می‌کند.
 */
(function () {
	'use strict';

	if (typeof window.WPMC === 'undefined') {
		return;
	}

	/**
	 * لاگ عیب‌یابی در کنسول (فقط وقتی «حالت عیب‌یابی» در تنظیمات روشن است).
	 */
	function log() {
		if (!WPMC.debug || !window.console || !console.info) {
			return;
		}
		try {
			console.info.apply(
				console,
				['[WPMC ' + (WPMC.version || '?') + ']'].concat(Array.prototype.slice.call(arguments))
			);
		} catch (e) {
			/* ignore */
		}
	}

	/* ------------------------------------------------------------------
	 * شناسایی فرم‌های المنتور
	 * ------------------------------------------------------------------ */

	/**
	 * آیا این <form> یک فرم المنتور است؟
	 * نشانه‌های معتبر: کلاس elementor-form یا فیلد پنهان form_id.
	 */
	function isElementorForm(form) {
		if (!form || form.tagName !== 'FORM') {
			return false;
		}
		if (form.classList && form.classList.contains('elementor-form')) {
			return true;
		}
		return !!form.querySelector('input[name="form_id"]');
	}

	/**
	 * شناسه‌ی فرم (Element ID) را برمی‌گرداند — اولویت با فیلد خودِ فرم.
	 */
	function getFormId(form) {
		var input = form.querySelector('input[name="form_id"]');
		if (input && input.value) {
			return input.value;
		}
		var el = form.closest ? form.closest('.elementor-element') : null;
		if (el) {
			var id = el.getAttribute ? el.getAttribute('data-id') : null;
			if (id) {
				return id;
			}
			if (el.id && el.id.indexOf('elementor-widget-') === 0) {
				return el.id.substring('elementor-widget-'.length);
			}
		}
		if (form.id && form.id.indexOf('elementor-form-') === 0) {
			return form.id.substring('elementor-form-'.length);
		}
		return '';
	}

	/**
	 * آیا این فرم باید کپچا بگیرد (طبق تنظیمات محدوده)؟
	 */
	function inScope(form) {
		if (!form || WPMC.scope === 'off') {
			return false;
		}
		// اگر کپچا قبلاً (دستی/کوت‌کد/فیلد پنل) در فرم هست، دوباره تزریق نکن.
		if (form.querySelector('.wpmc-captcha')) {
			return false;
		}
		if (WPMC.scope !== 'selected') {
			return true;
		}
		var ids = WPMC.formIds || [];
		var fid = getFormId(form);
		var ok = ids.indexOf(fid) !== -1;
		if (!ok) {
			log('فرم خارج از محدوده‌ی انتخاب‌شده است → تزریق نشد. form_id=' + fid + ' | لیست تنظیمات: ' + ids.join(', '));
		}
		return ok;
	}

	/* ------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------ */

	function post(body) {
		return fetch(WPMC.ajaxurl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		}).then(function (r) {
			return r.json();
		});
	}

	/* ------------------------------------------------------------------
	 * نقطه‌ی درج: داخل فرم، بعد از آخرین فیلد و بالای دکمه‌ی ارسال
	 * ------------------------------------------------------------------ */

	/**
	 * آیا عنصر «فیلدهای واقعیِ فرم» (input/textarea/select) دارد؟
	 * فیلدهای خودِ کپچا (wpmc_*) و inputهای مخفی/دکمه‌ای شمرده نمی‌شوند.
	 */
	function hasRealFields(el) {
		if (!el || !el.querySelector) {
			return false;
		}
		var sel =
			'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([name^="form_fields[wpmc_"]]), textarea, select';
		return !!el.querySelector(sel);
	}

	/**
	 * دکمه‌ی ارسال فرم (المنتور: .elementor-button).
	 * اولویت با دکمه‌های submit صریح؛ وگرنه آخرین دکمه‌ی فرم
	 * (دکمه‌ی ارسال در المنتور همیشه آخرین دکمه است).
	 */
	function findSubmitButton(form) {
		var btns = form.querySelectorAll('button[type="submit"], input[type="submit"]');
		if (btns.length) {
			return btns[btns.length - 1];
		}
		var els = form.querySelectorAll('.elementor-button');
		if (els.length) {
			return els[els.length - 1];
		}
		return null;
	}

	function placeBeforeSubmit(form, btn, box) {
		var node = btn;
		var parent;

		// از دکمه به سمت بالا حرکت می‌کنیم. اولین ancestor بدون فیلد واقعی
		// که داخل wrapper دارای فیلد قرار دارد، همان wrapper ارسال است.
		// کپچا قبل از آن و در همان parent درج می‌شود؛ بنابراین anchor همیشه
		// واقعاً فرزند parent است و insertBefore هیچ DOMException نمی‌دهد.
		while (node && node !== form) {
			parent = node.parentNode;
			if (!parent) {
				break;
			}
			if (!hasRealFields(node) && (parent === form || hasRealFields(parent))) {
				parent.insertBefore(box, node);
				return 'بالای wrapper دکمه‌ی ارسال (بعد از آخرین فیلد)';
			}
			node = parent;
		}

		// اگر wrapper دکمه و فیلدها یکی است، قبل از خود دکمه درج می‌کنیم.
		// این حالت هم کپچا را بعد از فیلدهای قبلی و بالای دکمه نگه می‌دارد.
		if (btn.parentNode && btn.parentNode !== form) {
			btn.parentNode.insertBefore(box, btn);
			return 'مستقیماً بالای دکمه‌ی ارسال';
		}
		if (btn.parentNode === form) {
			form.insertBefore(box, btn);
			return 'بالای دکمه‌ی ارسال';
		}

		return '';
	}

	function inject(form) {
		// نمونه‌ی قبلی (اگر بود) را حذف کن تا تکراری نشود.
		var old = form.querySelector('.wpmc-inject');
		if (old && old.parentNode) {
			old.parentNode.removeChild(old);
		}
		form.setAttribute('data-wpmc', '1');

		var box = document.createElement('div');
		box.className = 'wpmc-inject';
		box.innerHTML =
			'<div class="wpmc-captcha"><div class="wpmc-error">' + WPMC.i18n.load + '</div></div>';

		var btn = findSubmitButton(form);
		var where = '';
		try {
			if (btn) {
				where = placeBeforeSubmit(form, btn, box);
			}
			if (!where) {
				// دکمه‌ی ارسال پیدا نشد یا ساختار غیرمعمول بود: کپچا را
				// داخل wrapper فیلدها و در انتهای آن قرار می‌دهیم.
				var fw = form.querySelector('.elementor-form-fields-wrapper');
				if (fw) {
					fw.appendChild(box);
					where = 'انتهای فیلدها (ساختار غیرمعمول)';
				} else {
					form.appendChild(box);
					where = 'انتهای فرم';
				}
			}
		} catch (e) {
			// خطای DOM نباید رندر کپچا را از بین ببرد؛ fallback همیشه
			// یک parent معتبر دارد.
			try {
				form.appendChild(box);
				where = 'انتهای فرم (fallback)';
			} catch (ignored) {
				log('درج کپچا در فرم ممکن نشد.', e);
				return;
			}
		}
		log('کپچا به فرم تزریق شد. form_id=' + getFormId(form) + ' | نقطه‌ی درج: ' + where);

		var body = new URLSearchParams();
		body.set('action', 'wpmc_render');
		body.set('nonce', WPMC.nonce);
		body.set('prefix', 'ff');

		post(body).then(function (res) {
			if (res && res.success && res.data && res.data.html) {
				box.innerHTML = res.data.html;
			} else {
				box.innerHTML =
					'<div class="wpmc-captcha"><div class="wpmc-error">' + WPMC.i18n.err + '</div></div>';
			}
		}).catch(function () {
			box.innerHTML =
				'<div class="wpmc-captcha"><div class="wpmc-error">' + WPMC.i18n.err + '</div></div>';
		});
	}

	/**
	 * بررسی/تزریق برای تمام فرم‌های المنتور موجود در DOM (idempotent).
	 */
	function initForms() {
		var forms = document.querySelectorAll('form');
		Array.prototype.forEach.call(forms, function (form) {
			if (!isElementorForm(form)) {
				return;
			}
			if (form.getAttribute('data-wpmc') === '1' && form.querySelector('.wpmc-inject')) {
				return; // قبلاً تزریق شده.
			}
			if (inScope(form)) {
				inject(form);
			}
		});
	}

	/* ------------------------------------------------------------------
	 * اعتبارسنجی کلاینتی هنگام submit (فاست‌ترین بازخورد برای کاربر)
	 * ------------------------------------------------------------------ */

	document.addEventListener(
		'submit',
		function (e) {
			var form = e.target;
			if (!form || form.tagName !== 'FORM') {
				return;
			}
			var box = form.querySelector('.wpmc-inject .wpmc-captcha') || form.querySelector('.wpmc-captcha');
			if (!box) {
				return;
			}
			var input =
				form.querySelector('input.wpmc-input') ||
				form.querySelector('input[name="form_fields[wpmc_answer]"]') ||
				form.querySelector('input[name="wpmc_answer"]');
			if (!input) {
				return;
			}
			var oldErr = box.querySelector('.wpmc-submit-error');
			if (oldErr && oldErr.parentNode) {
				oldErr.parentNode.removeChild(oldErr);
			}
			if (String(input.value).replace(/[\s\u0600]/g, '') === '') {
				// توقف فرم پیش از دسترس‌یابی به المنتور/سرور:
				e.preventDefault();
				e.stopImmediatePropagation();
				var err = document.createElement('div');
				err.className = 'wpmc-error wpmc-submit-error';
				err.textContent = WPMC.i18n.empty;
				box.appendChild(err);
				log('ارسال فرم در کلاینت مسدود شد: جواب کپچا خالی بود.');
			}
		},
		true
	);

	/* ------------------------------------------------------------------
	 * دستگیره‌ی نوسازی (delegation؛ هم برای رندر سرور هم تزریق جاوااسکریپت)
	 * ------------------------------------------------------------------ */

	document.addEventListener('click', function (e) {
		if (!e || !e.target || !e.target.closest) {
			return;
		}
		var btn = e.target.closest('.wpmc-refresh');
		if (!btn) {
			return;
		}
		var wrap = btn.closest('.wpmc-captcha');
		if (!wrap) {
			return;
		}

		wrap.classList.add('wpmc-loading');

		var body = new URLSearchParams();
		body.set('action', 'wpmc_refresh');
		body.set('nonce', wrap.getAttribute('data-nonce') || WPMC.nonce);
		body.set('prefix', wrap.getAttribute('data-prefix') || '');

		post(body).then(function (res) {
			var parent = wrap.parentNode;
			if (res && res.success && res.data && res.data.html) {
				var tmp = document.createElement('div');
				tmp.innerHTML = res.data.html;
				var next = tmp.firstChild;
				if (next && parent) {
					parent.replaceChild(next, wrap);
				}
			} else {
				wrap.classList.remove('wpmc-loading');
				var err = document.createElement('div');
				err.className = 'wpmc-error';
				err.textContent = WPMC.i18n.rate;
				wrap.appendChild(err);
			}
		}).catch(function () {
			wrap.classList.remove('wpmc-loading');
		});
	});

	/* ------------------------------------------------------------------
	 * شروع + شناسایی فرم‌های دیربه‌DOM‌شده (پاپ‌آپ/تب‌های المنتور)
	 * ------------------------------------------------------------------ */

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initForms);
	} else {
		initForms();
	}

	if (typeof MutationObserver !== 'undefined' && document.body) {
		var observer = new MutationObserver(function (mutations) {
			var found = false;
			mutations.forEach(function (m) {
				if (found || !m.addedNodes) {
					return;
				}
				Array.prototype.forEach.call(m.addedNodes, function (n) {
					if (found || n.nodeType !== 1) {
						return;
					}
					if (n.tagName === 'FORM' || (n.querySelectorAll && n.querySelectorAll('form').length > 0)) {
						found = true;
					}
				});
			});
			if (found) {
				initForms();
			}
		});
		observer.observe(document.body, { childList: true, subtree: true });
	}
})();
